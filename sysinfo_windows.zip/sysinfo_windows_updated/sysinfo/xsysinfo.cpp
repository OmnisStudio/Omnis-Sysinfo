//
//  xsysinfo.cpp
//  sysinfo
//
//  Created by Andrei Augustin on 20/05/2019.
//  Copyright � 2019 Omnis Software Ltd. All rights reserved.
//

#include <extcomp.he>
#include <extfval.he>
#include <hwnd.he>

#include "sysinfo.he"
#include "xsysinfo.he"

using namespace std;

string int2hex_string::getHex(int value)
{
	stringstream hexSS;
	string hexString;
	hexSS << hex << value;
	hexSS >> hexString;
	return hexString;
}

void WMI_Interactor::setErrorHex(int error)
{
	errorHex = int2hex_string::getHex(error);
}

void WMI_Interactor::getWMI()
{
	if (WMI_Interactor::Model && WMI_Interactor::Manufacturer)
	{
		return;
	}
	else
	{
		HRESULT hres;

		// Initialize COM
		hres = CoInitializeEx(0, COINIT_APARTMENTTHREADED); // This will start in its own apartment so there won't be any issues if another component has already initialized COM
		if (FAILED(hres))
		{
			setErrorHex(hres);
			return;
		}

		//NEED TO CHECK IF THE FOLLOWING AND CoInitializeEx HAS ALREADY BEEN INITLIZED
		//Initialize 

		hres = CoInitializeSecurity(
			NULL,
			-1,      // COM negotiates service                  
			NULL,    // Authentication services
			NULL,    // Reserved
			RPC_C_AUTHN_LEVEL_DEFAULT,    // authentication
			RPC_C_IMP_LEVEL_IMPERSONATE,  // Impersonation
			NULL,             // Authentication info 
			EOAC_NONE,        // Additional capabilities
			NULL              // Reserved
		);

		if (FAILED(hres))
		{
			if (hres != 0x80010119) // If error code is 0x80010119, security has already been initialized, so we can just carry on
			{
				setErrorHex(hres);
				CoUninitialize();
				return;
			}
		}

		// Obtain the initial locator to Windows Management
		// on a particular host computer.
		IWbemLocator* pLoc = 0;

		hres = CoCreateInstance(
			CLSID_WbemLocator,
			0,
			CLSCTX_INPROC_SERVER,
			IID_IWbemLocator, (LPVOID*)& pLoc);

		if (FAILED(hres))
		{
			setErrorHex(hres);
			CoUninitialize();
			return;
		}

		IWbemServices* pSvc = 0;

		// Connect to the root\cimv2 namespace with the
		// current user and obtain pointer pSvc
		// to make IWbemServices calls.

		hres = pLoc->ConnectServer(

			_bstr_t(L"ROOT\\CIMV2"), // WMI namespace
			NULL,                    // User name
			NULL,                    // User password
			0,                       // Locale
			NULL,                    // Security flags                 
			0,                       // Authority       
			0,                       // Context object
			&pSvc                    // IWbemServices proxy
		);

		if (FAILED(hres))
		{
			setErrorHex(hres);
			pLoc->Release();
			CoUninitialize();
			return;
		}

		// Set the IWbemServices proxy so that impersonation
		// of the user (client) occurs.
		hres = CoSetProxyBlanket(

			pSvc,                         // the proxy to set
			RPC_C_AUTHN_WINNT,            // authentication service
			RPC_C_AUTHZ_NONE,             // authorization service
			NULL,                         // Server principal name
			RPC_C_AUTHN_LEVEL_CALL,       // authentication level
			RPC_C_IMP_LEVEL_IMPERSONATE,  // impersonation level
			NULL,                         // client identity 
			EOAC_NONE                     // proxy capabilities     
		);

		if (FAILED(hres))
		{
			setErrorHex(hres);
			pSvc->Release();
			pLoc->Release();
			CoUninitialize();
			return;
		}

		// Use the IWbemServices pointer to make requests of WMI.
		IEnumWbemClassObject* pEnumerator = NULL;
		hres = pSvc->ExecQuery(
			bstr_t("WQL"),
			bstr_t("SELECT * FROM Win32_ComputerSystem"),
			WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY,
			NULL,
			&pEnumerator);

		if (FAILED(hres))
		{
			setErrorHex(hres);
			pSvc->Release();
			pLoc->Release();
			CoUninitialize();
			return;
		}
		else
		{
			IWbemClassObject* pclsObj;
			ULONG uReturn = 0;

			while (pEnumerator)
			{
				hres = pEnumerator->Next(WBEM_INFINITE, 1,
					&pclsObj, &uReturn);

				if (0 == uReturn)
				{
					break;
				}

				VARIANT vtProp;

				// Get the value of the Manufacturer property
				hres = pclsObj->Get(L"Manufacturer", 0, &vtProp, 0, 0);
				Manufacturer = _com_util::ConvertBSTRToString(vtProp.bstrVal);
				VariantClear(&vtProp);

				// Get the value of the Model property
				hres = pclsObj->Get(L"Model", 0, &vtProp, 0, 0);
				Model = _com_util::ConvertBSTRToString(vtProp.bstrVal);
				VariantClear(&vtProp);

				pclsObj->Release();
				pclsObj = NULL;
			}

		}

		// Cleanup

		pSvc->Release();
		pLoc->Release();
		pEnumerator->Release();

		CoUninitialize();
		return;
	}
}

char* macAddressInteractor::getMacAddress()
{
	// Get adapters information
	ULONG bufferSize = 0;
	GetAdaptersInfo(0, &bufferSize);

	BYTE* ptrAdapter = new BYTE[bufferSize];
	PIP_ADAPTER_INFO ptrInfo = reinterpret_cast<PIP_ADAPTER_INFO>(ptrAdapter);

	DWORD adapterInformation = GetAdaptersInfo(ptrInfo, &bufferSize);

	// Get MAC address from adapter
	if (adapterInformation == ERROR_SUCCESS)
	{
		sprintf_s(
			macAddress,
			"%02X-%02X-%02X-%02X-%02X-%02X",
			ptrInfo->Address[0],
			ptrInfo->Address[1],
			ptrInfo->Address[2],
			ptrInfo->Address[3],
			ptrInfo->Address[4],
			ptrInfo->Address[5]);
	}

	// Memory de-allocation
	delete[] ptrAdapter;
	ptrAdapter = nullptr;


	return macAddress;
}
#define sysqlMethod_Count (sizeof(sysqlStaticFunctions)/sizeof(sysqlStaticFunctions[0]))

qbool sysinfo::getMacAddress(EXTfldval &returnValue)
{
	macAddressInteractor macAddressInteractor;

	char* macAddress[18];
	*macAddress = macAddressInteractor.getMacAddress();

	if (macAddress[16] != '\0') // If array has emtpy [16] element, getMacAddress failed
	{
		returnValue.setchar(*macAddress);
		return qtrue;
	}
	else
	{
		return qfalse;
	}
}

qbool sysinfo::getComputerName(EXTfldval &returnValue)
{
	TCHAR computerNameBuf[UNLEN + 1];
	DWORD bufCharCount = UNLEN + 1;

	GetComputerName(computerNameBuf, &bufCharCount);

	if (computerNameBuf == 0)
	{
		return qfalse;
	}
	else
	{
		CHRconvFromOs cfo(computerNameBuf, bufCharCount - 1); // bufCharCount-1 ensures that we get rid of the terminating null character.

		qchar * computerName = cfo.dataPtr();
		qlong len = cfo.len();

		returnValue.setChar(computerName, len);

		return qtrue;
	}
}

qbool sysinfo::getModel(EXTfldval &returnValue)
{
	WMI_Interactor WMI;
	char* Model = WMI.getModel();

	if (!Model)
	{
		return qfalse;
	}
	else
	{
		returnValue.setchar(Model);
		return qtrue;
	}
}

qbool sysinfo::getManufacturer(EXTfldval &returnValue)
{
	WMI_Interactor WMI;
	char* Manufacturer = WMI.getManufacturer();

	if (!Manufacturer)
	{
		return qfalse;
	}
	else
	{
		returnValue.setchar(Manufacturer);
		return qtrue;
	}
}

qbool sysinfo::getUsername(EXTfldval &returnValue)
{
	TCHAR usernameBuf[UNLEN + 1];
	DWORD bufCharCount = UNLEN + 1;

	GetUserName(usernameBuf, &bufCharCount);

	if (usernameBuf == 0)
	{
		return qfalse;
	}
	else
	{
		CHRconvFromOs cfo(usernameBuf, bufCharCount - 1); // bufCharCount-1 ensures that we get rid of the terminating null character.

		qchar * username = cfo.dataPtr();
		qlong len = cfo.len();

		returnValue.setChar(username, len);

		return qtrue;
	}
}