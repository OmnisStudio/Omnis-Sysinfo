/* $Header: svn://172.16.3.39/data/repos/trunk/Studio/O7EXE/MAC/omnisinc.h 2223 2012-11-07 16:20:40Z bmitchell $ */

/**************** Changes ******************
Date			Edit				Bug					Description
07-Nov-12	rmm_xc45								Changes to allow Xcode 4.5+ to be used for OSX build.
04-May-05	rmm5353			ST/HE/729		Implemented new serial number format for Studio 4.1 and later.
02-Jul-04 MHCW9										CW9 changes.
15 OCT 99 mpmCarbon								Carbon port
********************************************/

#define isXCOMPLIB

