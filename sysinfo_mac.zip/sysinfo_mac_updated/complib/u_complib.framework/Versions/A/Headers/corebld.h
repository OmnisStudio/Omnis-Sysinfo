/* $Header: svn://svn.omnis.net/trunk/Studio/EXTCOMP/CALLBACK/COCOA/corebld.h 11225 2015-02-04 17:46:03Z crichardson $ */

/**************** Changes ******************
Date			Edit				Bug					Description
03-Feb-15	CR											Created Cocoa web client header
********************************************/

#define isXCOMPLIB
#define isWEB
#define isRCCDESIGN

