//
//  xsysinfo.cpp
//  sysinfo
//
//  Created by Andrei Augustin on 20/05/2019.
//  Copyright © 2019 Omnis Software Ltd. All rights reserved.
//

#include <extcomp.he>
#include <extfval.he>
#include <hwnd.he>

#include "sysinfo.he"
#include "xsysinfo.he"

using namespace std;

void macAddressInteractor::Initialize()
{
  int error = 0;
  int sock = 0;
  int len = 0;
  int msgSeq = 0;
  createSocket();
  prepareMessage();
  sendMessage();
  readResponse();
  parseResponse();
};

int macAddressInteractor::readNlSock(int sockFd, char *bufPtr, int seqNum, int pId)
{
        struct nlmsghdr *nlHdr;
        int readLen = 0, msgLen = 0;
        do {
                // receive response from kernel
                if((readLen = recv(sockFd, bufPtr, BUFSIZE - msgLen, 0)) < 0)
                {
                        perror("SOCK READ: ");
                        return -1;
                }
                nlHdr = (struct nlmsghdr *)bufPtr;

                // check if header is valid
                if((0 == NLMSG_OK(nlHdr, readLen)) || (NLMSG_ERROR == nlHdr->nlmsg_type))
                {
                        perror("Error in received packet");
                        return -1;
                }

                // check if it's the last message
                if (NLMSG_DONE == nlHdr->nlmsg_type)
                {
                        break;
                }

                // else move the pointer to the buffer
                bufPtr += readLen;
                msgLen += readLen;

                // Check if its a multi part message, return if it is not
                if (0 == (nlHdr->nlmsg_flags & NLM_F_MULTI)) {
                        break;
                }
        } while((nlHdr->nlmsg_seq != seqNum) || (nlHdr->nlmsg_pid != pId));
        return msgLen;
}

void macAddressInteractor::createSocket()
{
    if ((sock = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_ROUTE)) < 0)
    {
      int error = 1;
    }
}

void macAddressInteractor::prepareMessage()
{
    if (error == 1)
    {
      return;
    }
    else
    {
      // Initialize message buffer
      memset(msgBuf, 0, BUFSIZE);

      // Point header and message structure to buffer
      nlMsg = (struct nlmsghdr *)msgBuf;

      // Populate the netlink message header
      nlMsg->nlmsg_len = NLMSG_LENGTH(sizeof(struct rtmsg)); // message length
      nlMsg->nlmsg_type = RTM_GETROUTE; // gets routes from kernel routing table

      nlMsg->nlmsg_flags = NLM_F_DUMP | NLM_F_REQUEST; // the message is a request for dump.
      nlMsg->nlmsg_seq = msgSeq++; // sequence of the message packet.
      nlMsg->nlmsg_pid = getpid(); // PID of process sending the request.
    }
}

void macAddressInteractor::sendMessage()
{
    if(send(sock, nlMsg, nlMsg->nlmsg_len, 0) < 0)
    {
      error = 1;
    }
}

void macAddressInteractor::readResponse()
{
    if (error == 1 )
    {
      return;
    }
    else
    {
      if((len = readNlSock(sock, msgBuf, msgSeq, getpid())) < 0)
      {
        error = 1;
      }
    }
}

void macAddressInteractor::parseResponse()
{
  if (error == 1)
  {
    return;
  }
  else
  {
    // Parse and read response
    rtInfo = (struct route_info *)malloc(sizeof(struct route_info));

    rtAttr = (struct rtattr *)RTM_RTA(rtMsg);
    rtLen = RTM_PAYLOAD(nlMsg);
    // PARSE ROUTES
    struct nlmsghdr *nlHdr = nlMsg;

    rtMsg = (struct rtmsg *)NLMSG_DATA(nlHdr);
    rtAttr = (struct rtattr *)RTM_RTA(rtMsg);
    rtLen = RTM_PAYLOAD(nlHdr);

    for (; RTA_OK(rtAttr,rtLen); rtAttr = RTA_NEXT(rtAttr,rtLen))
    {
        switch (rtAttr->rta_type)
        {
            case RTA_OIF:
            {
                if_indextoname(*(int *)RTA_DATA(rtAttr), rtInfo->ifName);
                break;
            }
        }
    }

    string strInterface = rtInfo->ifName;

    char interfaceName[strInterface.length()];
    strcpy(interfaceName, strInterface.c_str());

    free(rtInfo);
    close(sock);

    // now use main interface to get mac address
    struct ifreq ifr;
    int s;
    if ((s = socket(AF_INET, SOCK_STREAM,0)) < 0)
    {
        error = 1;
    }

    strcpy(ifr.ifr_name, interfaceName);
    if (ioctl(s, SIOCGIFHWADDR, &ifr) < 0)
    {
        error == 1;
    }
    else
    {
        unsigned char *hwaddr = (unsigned char *)ifr.ifr_hwaddr.sa_data;

        close(s);
        sprintf(
                    macAddress,
                    "%02X-%02X-%02X-%02X-%02X-%02X",
                    hwaddr[0],
                    hwaddr[1],
                    hwaddr[2],
                    hwaddr[3],
                    hwaddr[4],
                    hwaddr[5]);


  }
}
}

void macAddressInteractor::getMacAddress(char (&addressBuffer)[18])
{
 copy(begin(macAddress), end(macAddress), begin(addressBuffer));
}


qbool sys_info::getMacAddress(EXTfldval &returnValue)
{
  char macAddress[18];
  macAddressInteractor mac;
  mac.Initialize();
  mac.getMacAddress(macAddress);

  if (macAddress[16] != '\0') // If array has emtpy [16] element, getMacAddress failed
  {
      returnValue.setchar(macAddress);
      return qtrue;
  }
  else
  {
      return qfalse;
  }
}

qbool sys_info::getComputerName(EXTfldval &returnValue)
{
  char computerName[HOST_NAME_MAX];

  gethostname(computerName, HOST_NAME_MAX);

  if (computerName)
  {
      returnValue.setchar(computerName);
      return qtrue;
  }
  else
  {
      return qfalse;
  }
}

qbool sys_info::getModel(EXTfldval &returnValue)
{
  string computerModel;

  ifstream computerModelFile("/sys/class/dmi/id/product_name");
  getline(computerModelFile, computerModel);
  computerModelFile.close();

  if (computerModel.length() > 0)
  {
      returnValue.setchar(computerModel);
      return qtrue;
  }
  else
  {
      return qfalse;
  }
}

qbool sys_info::getManufacturer(EXTfldval &returnValue)
{
  string manufacturer;

  ifstream manufacturerFile("/sys/class/dmi/id/board_vendor");
  getline(manufacturerFile, manufacturer);
  manufacturerFile.close();

  if (manufacturer.length() > 0)
  {
      returnValue.setchar(manufacturer);
      return qtrue;
  }
  else
  {
      return qfalse;
  }
}

qbool sys_info::getUsername(EXTfldval &returnValue)
{
  char* username;
  username = getenv("USER");
  if (username)
  {
      returnValue.setchar(username);
      return qtrue;
  }
  else
  {
      return qfalse;
  }
}
