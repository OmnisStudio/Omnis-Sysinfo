#! /bin/sh

export LD_LIBRARY_PATH=`pwd`/omnisxi:$LD_LIBRARY_PATH
export V4DIR=`pwd`/omnisxi
export OMNISRC=`pwd`/omnisrc
export PATH=$PATH:$OMNISRC
sed -i 's|Template=.*|Template='`pwd`'/omnisrc/omnisrc.tpl|' `pwd`/omnisrc/omnisrc.ini
sed -i 's|IncludeDirs=.*|IncludeDirs='`pwd`'/omnisxi|' `pwd`/omnisrc/omnisrc.ini

rm -f -r releaseuni-headless
mkdir releaseuni-headless
mkdir releaseuni-headless/xcomp

rm -f -r releaseuni
mkdir releaseuni
mkdir releaseuni/xcomp

echo
echo ==== BuildAll ====
echo LD_LIBRARY_PATH is $LD_LIBRARY_PATH
echo V4DIR is $V4DIR
echo OMNISRC is $OMNISRC
echo XCOMP components will be in `pwd`/releaseuni/xcomp
echo Headless XCOMP components will be in `pwd`/releaseuni-headless/xcomp

echo
echo ==== Headless SYSINFO ====
cd sysinfo
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo === SYSINFO ===
cd sysinfo
rm -f -r releaseuni
make Release
cp releaseuni/*.so ../releaseuni/xcomp
cd ..

#echo
#echo ==== Headless CALENDAR ====
#cd calendar
#rm -f -r releaseuni
#make Release omheadless=1
#cp releaseuni/*.so ../releaseuni-headless/xcomp
#mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== CALENDAR ====
# #cd calendar
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless DAMGENRC ====
# #cd damgenrc
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== DAMGENRC ====
# #cd damgenrc
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless DOCVIEW ====
# #cd docview
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== DOCVIEW ====
# #cd docview
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless FILEOPS ====
# #cd fileops
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== FILEOPS ====
# #cd fileops
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless FONTOPS ====
# #cd fontops
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== FONTOPS ====
# #cd fontops
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless GENERIC ====
# #cd generic
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== GENERIC =====
# #cd generic
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless GENERIC2 ====
# #cd generic2
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== GENERIC2 ====
# #cd generic2
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless GENERIC3 ====
# #cd generic3
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== GENERIC3 ====
# #cd generic3
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless GENERIC4 ====
# #cd generic4
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== GENERIC4 ====
# #cd generic4
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless HTML ====
# #cd html
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== HTML ====
# #cd html
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless ICNARRAY ====
# #cd icnarray
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== ICNARRAY ====
# #cd icnarray
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless MARQUEE ====
# #cd marquee
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== MARQUEE ====
# #cd marquee
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless OCLOCK ====
# #cd oclock
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== OCLOCK ====
# #cd oclock
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless OMNISICN ====
# #cd omnisicn
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== OMNISICN ====
# #cd omnisicn
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless PICLIST ====
# #cd piclist
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== PICLIST ====
# #cd piclist
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless PROGRESS ====
# #cd progress
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== PROGRESS ====
# #cd progress
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless SLIDER ====
# #cd slider
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== SLIDER ====
# #cd slider
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless TILE ====
# #cd tile
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== TILE ====
# #cd tile
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless WASH ====
# #cd wash
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== WASH ====
# #cd wash
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless WORKER ====
# #cd worker
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== WORKER ====
# #cd worker
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
# #echo
# #echo ==== Headless ZOOM ====
# #cd zoom
# #rm -f -r releaseuni
# #make Release omheadless=1
# #cp releaseuni/*.so ../releaseuni-headless/xcomp
# #mv releaseuni releaseuni-headless
# #cd ..
# #
# #echo
# #echo ==== ZOOM ===
# #cd zoom
# #rm -f -r releaseuni
# #make Release
# #cp releaseuni/*.so ../releaseuni/xcomp
# #cd ..
# #
echo
echo ============
echo = Finished =
echo ============
