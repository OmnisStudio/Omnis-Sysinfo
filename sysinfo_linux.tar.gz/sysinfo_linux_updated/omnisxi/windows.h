/* $Header: svn://svn.omnis.net/trunk/Studio/UNIX/OMNISXI/windows.h 18468 2017-11-23 11:06:24Z bmitchell $ */

// windows.h
//
//Copyright	(C)	Blyth Holdings Inc 1999

/**************** Changes ******************
Date			Edit			Bug						Description
22-Nov-17	rmm9567		ST/FU/718			Begin-end print job issue on Linux.
17-Nov-17	rmm9564		ST/WT/1872		Linux resource leak (threads).
04-Jul-17	rmm9422									64 bit porting issue with Linux owner-draw menus.
13-Apr-17	rmm9322									Lock-up printing PDF in multi-threaded Linux server.
14-Feb-17	rmmheadless							Support for headless Omnis server.
30-Aug-16	rmm9025		ST/NV/059			Added support for long pathnames to FileOps and to core qfile.
19-Aug-16	rmm9010		ST/EC/1416		Added support for large files (files with a size > maximum signed 32 bit integer).
18-Aug-16	rmm9008		ST/JS/1378		Added ability to configure a time offset that affects #D and #T.
23-Mar-16	rmm8816									Scroll bar colours are now configurable.
08-Jan-16	rmm8706			ST/HE/1353	Draw titled tqwnd's to look more like Windows 8/10.
10-Mar-15	rmm_cwo									Re-implemented Cocoa port top level window ordering.
16-Oct-14 gra1008                 Linux ODBC DAM compile issue
19-Aug-13	rmm64bitux							Linux 64 bit port.
21-Jan-13	rmm7796		ST/PF/782			Problem with multiple timer messages on Linux.
15-Jan-12	rmm7790									Problem with saved position of main window.
21-Sep-12	gra0864									Added TryEnterCriticalSection
08-Jun-12	rmm7513									Special mode to allow uninstaller to run Omnis to deactivate.
26-Apr-12	rmm64bit2								64 bit portability changes.
28-Sep-10	rmm6982									New program icon.
26-Jan-10	rmm6879		ST/SS/375			Using clipboard in KDE or GNOME dialog caused performance problem.
17-Dec-09	rmm6814		ST/WT/1527		Refreshing a remote form in Firefox 3.5 on Linux caused a crash.
10-Dec-09	rmm6807									Linux version did not work with KDE4.
16-Jul-09	rmm6666		ST/BE/383			Problem with tooltips and mouse wheel.
16-Jul-09	rmm6665		ST/TB/281			Problem with floating toolbars on Linux.
16-Jul-09	rmm6664		ST/RC/1072		Crash opening report on Linux.
15-Jun-09	rmm_nc									New controls and supporting APIs.
21-Jan-09	rmm6583		ST/WT/1404		Problem scrolling mobile form design window on Linux.
05-Jan-09	AECLIP									Clipboard enhancements (version 8.1)
02-Jul-08	rmm_rfmenu							Context menus for remote forms.
02-Nov-07	rmm6262									Added ability to configure Linux menu bar font size.
04-Sep-07	rmm6223		ST/EC/1113		Performance problem with CopyFile.
06-Aug-07	rmm6202									Various Linux issues.
05-Jul-07	rmm6146									Added $norefresh property to window instances,to improve performance especially during the setting of complex grid exceptions.
21-Jun-07	pk6796									print messages - no supported on unix
04-May-07	rmmunilnx3							Unicode Linux stage 3.
23-Apr-07	rmm6038		ST/WT/1228		Problems with large scroll ranges.
20-Feb-07	rmm6006		ST/HI/1468		Notation helper was broken on Linux.
14-Feb-07	rmm5993		ST/HE/922			Better support for italicised text on Win32.
06-Feb-07	rmm5974		ST/EM/176			Keyboard messages were sometimes lost on Linux during testesc.
29-Jan-07	rmm5957									Fixed memory leaks.
12-Jan-07	rmm5952		ST/WT/1185		Issue with clicks on remote form data grid.
16-Oct-06	rmmcups									Linux: Use CUPS for printing.
25-Sep-06	rmmunilnx2							Linux Unicode: PDF device.
12-Sep-06	rmmunilnx								Linux Unicode: Fonts.
07-Apr-06	rmm5703		ST/HE/267			Clipboard now works on Linux/Solaris when interacting with other applications 
29-Mar-06	rmm5700		ST/EC/982			Bad interaction between timers and menu tracking.
05-Jan-06	rmm5564									Fixed issues identified by GCC on Linux.
01-Feb-05	rmm5261		UN/WO/1774		$righttoleft now has additional functionality.
12-Jan-05	AE6560		ST/DB/598: 		Added XEV_IsWindowQueued
21-Jun-04	AE6473		ST/WC/381: 		Attempt to enforce modal windows
18-Nov-03	AE6369		ST/LO/090: 		Localisation strings not appearing in dlgs (added HOOK+button accel text)
10-Feb-03 MHSOL										Solaris changes
05-Feb-03	AE6158		ST/EC/544: 		Enhanced "Launch Program" to allow capture of the output
05-Feb-03	AE6201									Implemented	SetMenuItemInfo
15-Nov-02	AE6169		ST/PF/222: 		Made "prompt for input" a permanantly on top window (just for unix!)
31-Jul-02 MHUNILX									Linux unicode changes.
04-Mar-02 AE6063		ST/HI/1324: 	Unix: Window $top/$left decreasing when opened & saved in design mode
27-Feb-02	AE6061		ST/HI/1321: 	All fonts on KDE2 are in bold italic (upped OMNISXI version no.)
07-Dec-01 MHXPUX									Unix compatibility changes for XP code.
20-Nov-00	rmm3941									Implemented Sleep.
12-Oct-00	AESOL										Added ordermsb for Solaris-Sparc processor
07-Aug-00 mlr0039									Added TA_RTLREADING for arabic support 
31-Jul-00 AE5098		ST/WO/1150		Added XIgrabPointer and XIungrabPointer (V1.7)
06-Jul-00	rmm3838		ST/EC/504			Fonts were still incorrect on Linux.
22-May-00	rmm3766									Implemented TLS calls needed by omnis.
02-May-00 MHn0109		ST/FU/264			Added function to convert File Time to a local system time format.
19-Apr-00	rmm3730		ST/RC/641			Added ability to configure printer margins on Linux.
24-Feb-99	rmm3667		ST/WO/1083		Unix keyboard focus issue, when editing tree nodes.
24-Feb-00	rmm3666		ST/HI/1052		Problems with fonts.
08-Feb-00	AE5005		ST/EC/410: 		Bitmap hiliting failed on Linux (added BitBltHilite)
07-Jan-00	AEINST									Installer changes
30-Nov-99 MHPORT									Added GetCommTimeouts function.
16-Nov-99	rmm3524									Added more thread APIs and critical section APIs.
17-Sep-99	AEUNIX									Initial implementation
*/

#ifndef _WINDOWS_H_
#define _WINDOWS_H_

/************** VERSION NUMBER UPDATE ON NEW BUILDS****************/
#define XI_MAJOR			"10"
#define XI_MINOR			"1"	// rmm3666 // rmm3838	AE5098 // rmm5703 // rmmcups // rmm5952 // rmm5957 // rmm5974 // rmm5993 // rmm6038 // rmmunilnx3 // rmm6146 // rmm6223 // rmm6262 // rmm6583 // rmm6664 // rmm6814 // rmm6982 // rmm7796
/******************************************************************/

#include "winerror.h"
#include <stdint.h>	// rmm64bitux

#ifdef __cplusplus
extern "C" {
#endif

#pragma pack(1)

#define HFILE_ERROR   0xffffffffL

#define OMNIS_HINSTANCE  ((HINSTANCE) 1)    // Instance that is OMNIS.EXE
#define far
#define FAR
#define CALLBACK
#define GDIAPI
#define HWNDAPI
#define GDIPICTAPI
#define OMNISAPI
#define RCCAPI
#define ECOAPI
#define CRBAPI
#define WINAPI
#define APIENTRY WINAPI // MHUX001
#define PASCAL
#define __declspec(nothrow) 
#define dllExport
#define __stdcall

#define TRUE 1
#define FALSE 0
#define MAX_PATH  4096	// rmmcups: more space - allows for UTF-8 // rmm9025: Not ideal, but in practice this will be fine
#define _MAX_PATH MAX_PATH
#define R2_COPYPEN 1
#define R2_NOTXORPEN 2
#define R2_MERGEPEN 4
#define R2_XMODE  0x80
#define R2_XMASK  0x7f

#define CONST const
#define VOID void
#ifndef _TCHAR_H_ // MHSOL
typedef char TCHAR;
#endif
typedef char CHAR;
// Start rmm64bitux
typedef int32_t INT;
typedef int16_t SHORT;
typedef uint16_t USHORT;
typedef int32_t LONG;
typedef int32_t* PLONG;
// End rmm64bitux
typedef unsigned char BYTE;
typedef BYTE* PBYTE;
typedef BYTE* LPBYTE;
#ifndef ODBCDAM //gra1008
typedef unsigned char BOOL;
#endif
typedef void* HANDLE;
typedef HANDLE *LPHANDLE;	// rmmcups
typedef void* HRESULT; // MHXPUX
typedef uint16_t WORD;	// rmm64bitux
typedef WORD* LPWORD;
typedef uint32_t DWORD; // rmm64bitux
typedef DWORD* LPDWORD;
// Start rmm64bitux
typedef uint32_t 	UINT;
typedef intptr_t  INT_PTR;
typedef uintptr_t UINT_PTR;
typedef intptr_t  LONG_PTR;
typedef uintptr_t ULONG_PTR;
typedef ULONG_PTR DWORD_PTR;
typedef UINT_PTR  WPARAM;
typedef LONG_PTR  LPARAM;
typedef LONG_PTR  LRESULT;
typedef DWORD 		COLORREF;
// End rmm64bitux
typedef void* ATOM;
typedef UINT_PTR OMTHREADID;			// rmmheadless: pthread ids are 64 bit

// Object Types
typedef void* HMODULE;
typedef void* HFILE;
typedef void* HPALETTE;
typedef void* HINSTANCE;
typedef void* HCURSOR;
typedef void* HMETAFILE;
typedef void* HDROP;
typedef void* HMENU;
typedef void* HENHMETAFILE;
typedef void* HGDIOBJ;
typedef void* HHOOK;

// Function pointers types
typedef void* WNDPROC;
typedef void* FARPROC;
typedef void* DLGPROC;
typedef LRESULT (CALLBACK* HOOKPROC) (int,WPARAM,LPARAM);
typedef VOID (CALLBACK* LINEDDAPROC)(int,int,LPARAM);
typedef int (CALLBACK* FONTENUMPROC)(void*,void*,DWORD,LPARAM);
typedef int (CALLBACK* OLDFONTENUMPROC)(void*,void*,DWORD,LPARAM);

typedef void* PFNCALLBACK;

typedef void* LPCDLGTEMPLATE;

typedef const char* LPCTSTR;
typedef const char* LPCSTR;
typedef char* LPSTR;
typedef char* LPTSTR;
typedef unsigned char* HPSTR;
typedef void* LPVOID;
typedef void* PVOID;
typedef const void* LPCVOID;
#ifndef ODBCDAM //gra1008
typedef short *LPCWSTR;
#endif

#define VOID void



#define _TEXT(a)	    ((LPTSTR)a)		
#define MAKEWORD(a, b)      ((WORD)(((BYTE)(a)) | ((WORD)((BYTE)(b))) << 8))
#define MAKELONG(a, b)      ((LONG)(((WORD)(a)) | ((DWORD)((WORD)(b))) << 16))
#define MAKEWPARAM(a,b)     (WPARAM)MAKELONG(a,b)
#define MAKELPARAM(l, h)    ((LPARAM)(DWORD)MAKELONG(l, h)) // rmm8816
#define LOWORD(l)           ((WORD)(l))
#define HIWORD(l)           ((WORD)(((DWORD)(l) >> 16) & 0xFFFF))
#define LOBYTE(w)           ((BYTE)(w))
#define HIBYTE(w)           ((BYTE)(((WORD)(w) >> 8) & 0xFF))
#define MAX(a,b)  (((a)>(b)) ? (a) : (b))
#define MIN(a,b)  (((a)<(b)) ? (a) : (b))

// Accessor functions - Set pLSBfirst to TRUE for maintain LittleEndian byte ordering
WORD GETWORD(void* pWordPtr,BOOL pLSBfirst);
void SETWORD(void* pDestPtr,WORD pNewValue,BOOL pLSBfirst);
DWORD GETDWORD(void* pDWordPtr,BOOL pLSBfirst);
void SETDWORD(void* pDestPtr,DWORD pNewValue,BOOL pLSBfirst);

#ifndef NULL
#define NULL 0
#endif

#define GMEM_FIXED 0
#define GMEM_ZEROINIT  1
#define GMEM_MODIFY 2
#define GMEM_DISCARDED 4
#define GMEM_DISCARDABLE 8
#define GMEM_MOVEABLE 16
#define GHND  GMEM_ZEROINIT

INT GlobalSize(HANDLE han); // rmm64bitux
void GlobalFree(HANDLE han);
void* GlobalLock(HANDLE han);
void GlobalUnlock(HANDLE han);
HANDLE GlobalReAlloc(HANDLE han,INT size,INT flags); // rmm64bitux
HANDLE GlobalAlloc(INT flags,INT size); // rmm64bitux
WORD GlobalFlags(HANDLE han);
HANDLE GlobalHandle(HANDLE);

typedef struct tagBITMAP
{
    LONG        bmType;
    LONG        bmWidth;
    LONG        bmHeight;
    LONG        bmWidthBytes;
    WORD        bmPlanes;
    WORD        bmBitsPixel;
    LPVOID      bmBits;
} BITMAP;

/************************ Little-Endian Byte-Packed *************************/
/* The following structures are stored in Little-Endian byte-packing format */
/* Members must be accessed using GETxWORD and SETxWORD functions pLSBfirst */
/* set to TRUE.       ***DO NOT ACCESS THE MEMBERS DIRECTLY!!!***           */
#pragma pack(1)			/*ALLPACK*/
typedef struct tagBITMAPINFOHEADER
{
        DWORD      biSize;
        LONG       biWidth;
        LONG       biHeight;
        WORD       biPlanes;
        WORD       biBitCount;
        DWORD      biCompression;
        DWORD      biSizeImage;
        LONG       biXPelsPerMeter;
        LONG       biYPelsPerMeter;
        DWORD      biClrUsed;
        DWORD      biClrImportant;
} BITMAPINFOHEADER, *LPBITMAPINFOHEADER;

/* constants for the biCompression field */
#define BI_RGB        0L
#define BI_RLE8       1L
#define BI_RLE4       2L
#define BI_BITFIELDS  3L
#define BI_XCOL       127L

typedef struct tagBITMAPCOREHEADER {
        DWORD   bcSize;                 /* used to get to color table */
        WORD    bcWidth;
        WORD    bcHeight;
        WORD    bcPlanes;
        WORD    bcBitCount;
} BITMAPCOREHEADER, *LPBITMAPCOREHEADER;
typedef struct tagRGBQUAD {
        BYTE    rgbBlue;
        BYTE    rgbGreen;
        BYTE    rgbRed;
        BYTE    rgbReserved;
} RGBQUAD, *LPRGBQUAD;
typedef struct tagBITMAPINFO {
    BITMAPINFOHEADER    bmiHeader;
    RGBQUAD             bmiColors[1];
} BITMAPINFO, *LPBITMAPINFO, *PBITMAPINFO;
typedef struct tagBITMAPFILEHEADER {
        WORD    bfType;
        DWORD   bfSize;
        WORD    bfReserved1;
        WORD    bfReserved2;
        DWORD   bfOffBits;
} BITMAPFILEHEADER, *LPBITMAPFILEHEADER, *PBITMAPFILEHEADER;
typedef struct tagRGBTRIPLE
{
    BYTE    rgbtBlue;
    BYTE    rgbtGreen;
    BYTE    rgbtRed;
} RGBTRIPLE, *LPRGBTRIPLE;

typedef struct tagICONDIRENTRY
{
  BYTE bWidth;
  BYTE bHeight;
  BYTE bColorCount;
  BYTE bReserved;
  WORD wPlanes;
  WORD wBitCount;
  DWORD dwBytesInRes;
  DWORD dwImageOffset;
} ICONDIRENTRY, *LPICONDIRENTRY;

typedef struct tagICONIMAGE
{
  BITMAPINFOHEADER icHeader;
  RGBQUAD icColors[1];
  BYTE icXOR[1];
  BYTE icAND[1];
} ICONIMAGE, *LPICONIMAGE;

typedef struct tagICONDIR
{
  WORD idReserved;
  WORD idType;
  WORD idCount;
  ICONDIRENTRY idEntries[1];
} ICONDIR, *LPICONDIR;
#pragma pack()   				/*ALLPACK*/
/****************************************************************************/

typedef struct tagSIZE
{
    LONG        cx;
    LONG        cy;
} SIZE, *LPSIZE;

typedef struct tagRECT
{
  LONG    left;
  LONG    top;
  LONG    right;
  LONG    bottom;
} RECT, *LPRECT;

typedef struct tagPOINT
{
    LONG  x;
    LONG  y;
} POINT, *LPPOINT;

// The POINTS members are defined to be platform independant to allow MAKEPOINTS to work
typedef struct tagPOINTS
{
#ifdef ordermsb
  SHORT y;
  SHORT x;
#else
  SHORT x;
  SHORT y;
#endif
} POINTS;

typedef short CSHORT;
#define __int64 long long
typedef unsigned __int64 DWORDLONG;
typedef __int64 LONGLONG;
typedef DWORDLONG ULONGLONG;

typedef union _LARGE_INTEGER {
    struct {
#ifdef ordermsb
        LONG     HighPart;
        DWORD    LowPart;
#else
        DWORD    LowPart;
        LONG     HighPart;
#endif
    } s;
    LONGLONG QuadPart;
} LARGE_INTEGER, *PLARGE_INTEGER;

typedef union _ULARGE_INTEGER {
    struct {
#ifdef ordermsb
        DWORD    HighPart;
        DWORD    LowPart;
#else
        DWORD    LowPart;
        DWORD    HighPart;
#endif
    } s;
    ULONGLONG QuadPart;
} ULARGE_INTEGER, *PULARGE_INTEGER;

// Start rmmunilnx2
// Critical sections
struct S_CRITICAL_SECTION
{
	void 	*mCs;
};

typedef struct S_CRITICAL_SECTION *LPCRITICAL_SECTION;
typedef struct S_CRITICAL_SECTION CRITICAL_SECTION;

VOID InitializeCriticalSection(LPCRITICAL_SECTION lpCriticalSection);
VOID DeleteCriticalSection(LPCRITICAL_SECTION lpCriticalSection);
VOID EnterCriticalSection(LPCRITICAL_SECTION lpCriticalSection);
BOOL TryEnterCriticalSection(LPCRITICAL_SECTION lpCriticalSection); //gra0864
VOID LeaveCriticalSection(LPCRITICAL_SECTION lpCriticalSection);
// End critical sections
// Start rmmheadless
typedef void (*CSERRORPROC)(const char *pCall, int pErrorCode);
void SetCriticalSectionErrorProc(CSERRORPROC pErrorProc);
#ifdef isheadless
	typedef void (*HDERRORPROC)(const char *pError, BOOL pThrowException);
	void SetHeadlessErrorProc(HDERRORPROC pErrorProc);
#endif
// End rmmheadless

// rmmheadless: Define omneedbasicdefines this way because the resource compiler does not support #if
#ifdef isheadless
	#define omneedbasicdefines
#else
	#ifndef BUILD_XI
		#define omneedbasicdefines
	#endif
#endif

#ifdef omneedbasicdefines // rmmheadless
	typedef HGDIOBJ HWND;
	typedef HGDIOBJ HFONT;
	typedef HGDIOBJ HPEN;
	typedef HGDIOBJ HBRUSH;
	typedef HGDIOBJ HBITMAP;
	typedef HGDIOBJ HBITMAPMASK;
	typedef HGDIOBJ HRGN;
	typedef HGDIOBJ HDC;
	typedef HGDIOBJ HICON;
	#ifdef isheadless
		#ifndef omresources
			#ifdef BUILD_XI
				#include "winpriv.h" // rmmheadless
			#endif
		#endif
	#else
		typedef HGDIOBJ HPRINTER;	// rmmcups
	#endif
#endif

#define LF_FACESIZE         128	// rmmheadless
typedef struct tagLOGFONT
{
		#ifdef isheadless
			HDC			mHdc;			// rmmheadless: HDC to be used to obtain the DPI
		#endif
    LONG      lfHeight;
    LONG      lfWidth;
    LONG      lfEscapement;
    LONG      lfOrientation;
    LONG      lfWeight;
    BYTE      lfItalic;
    BYTE      lfUnderline;
    BYTE      lfStrikeOut;
    BYTE      lfCharSet;
    BYTE      lfOutPrecision;
    BYTE      lfClipPrecision;
    BYTE      lfQuality;
    BYTE      lfPitchAndFamily;
    CHAR      lfFaceName[LF_FACESIZE];
} LOGFONT,*LPLOGFONT;

#ifndef isheadless	// rmmheadless
	#ifdef BUILD_XI
		#include "winpriv.h"
	#endif
#endif

// Start rmmunilnx2
typedef struct tagFONTINFO
{
	CHAR				lfFaceName[LF_FACESIZE];
	CHAR				lfFontFilePath[MAX_PATH];
	int					lfHeight;
	int					lfAscent;
	int					lfDescent;
	BOOL				lfBold;
	BOOL				lfItalic;
	BOOL				lfUnderline;
} FONTINFO, *LPFONTINFO;

#define MAKEPOINTS(l) (*((POINTS FAR*)&(l))) 

#define BS_PATTERN          3

typedef struct 
{
	HDC		hdc;
	BOOL	fErase;
	RECT	rcPaint;
	BOOL	fRestore;
	BOOL	fIncUpdate;
	BOOL	rgbReserved[16];	
} PAINTSTRUCT, *LPPAINTSTRUCT;

/* Stock Logical Objects */
#define	BLACK_BRUSH			0
#define	DKGRAY_BRUSH		1
#define	GRAY_BRUSH			2
#define	LTGRAY_BRUSH		3
#define	WHITE_BRUSH			4
#define OEM_FIXED_FONT 10
#define ANSI_FIXED_FONT 11
#define ANSI_VAR_FONT   12
#define SYSTEM_FONT         13
#define DEVICE_DEFAULT_FONT 14
#define SYSTEM_FIXED_FONT  16

#define WHITE_PEN           6
#define BLACK_PEN           7

// Region
#define ERROR 0
#define NULLREGION          1
#define SIMPLEREGION        2
#define COMPLEXREGION       3

#define ALTERNATE                    1
#define RGN_AND             1
#define RGN_OR              2
#define RGN_XOR             3
#define RGN_DIFF            4
#define RGN_COPY            5
HRGN    CreateRoundRectRgn(int, int, int, int, int, int);
HRGN    CreateRectRgn(int, int, int, int);
HRGN		CreatePolygonRgn(const POINT *, int, int);
int  GetClipRgn(HDC,HRGN);
int		SelectClipRgn(HDC pHdc, HRGN);
int     CombineRgn(HRGN, HRGN, HRGN, int);
BOOL   SetRectRgn(HRGN, int, int, int, int);
int   GetRgnBox(HRGN, LPRECT);
int  OffsetRgn(HRGN, int, int);
BOOL EqualRgn(HRGN, HRGN);
BOOL PtInRegion(HRGN, int, int);
BOOL InvertRgn(HDC, HRGN);
BOOL DeleteObject(void*);

#define DI_MASK         0x0001
#define DI_IMAGE        0x0002
#define DI_NORMAL       0x0003
#define DI_COMPAT       0x0004
#define DI_DEFAULTSIZE  0x0008


// HDC 
#define TRANSPARENT 1
int   SetBkMode(HDC, int);

typedef struct tagWINDOWPOS
{
	HWND		hwnd;
	HWND		hwndInsertAfter;
	INT		x;
	INT		y;
	INT		cx;
	INT		cy;
	DWORD	flags;
}WINDOWPOS, *LPWINDOWPOS, *PWINDOWPOS;
BOOL SendNCcalc(HWND pHwnd,RECT* pCrect, WINDOWPOS* wndPos );

typedef struct tagNCCALCSIZE_PARAMS
{
    RECT       rgrc[3];
    PWINDOWPOS lppos;
} NCCALCSIZE_PARAMS, *LPNCCALCSIZE_PARAMS;

// Window messages
#define WM_GETTEXT   										0x000D
#define WM_SETREDRAW                    0x000B
#define WM_GETFONT                      0x0031
#define WM_ENTERIDLE                    0x0121
#define WM_CANCELMODE                   0x001F
#define WM_WININICHANGE                 0x001A
#define WM_INITDIALOG                   0x0110
#define WM_COMMAND                      0x0111
#define WM_SYSCOMMAND                   0x0112
#define WM_SYSCOLORCHANGE               0x0015
#define WM_DISPLAYCHANGE                0x007E
#define WM_QUERYDRAGICON                0x0037
#define WM_CLOSE                        0x0010
#define WM_QUERYENDSESSION              0x0011
#define WM_NCCREATE											0x0081
#define WM_NCHITTEST                    0x0084
#define WM_MENUSELECT                   0x011F
#define WM_SYSKEYDOWN                   0x0104
#define WM_SYSKEYUP                     0x0105
#define WM_SYSCHAR                      0x0106
#define WM_SYSDEADCHAR                  0x0107
#define WM_ENDSESSION                   0x0016
#define WM_INITMENUPOPUP                0x0117
#define WM_SETFOCUS                     0x0007
#define WM_KILLFOCUS                    0x0008
#define WM_NCCALCSIZE                   0x0083
#define WM_ACTIVATEAPP                  0x001C
#define WM_ACTIVATE                     0x0006
#define WM_CHAR                         0x0102
#define WM_DEADCHAR                     0x0103
#define WM_MBUTTONDOWN                  0x0207
#define WM_MBUTTONUP                  	0x0208
#define WM_QUIT                         0x0012
#define WM_ENTERMENULOOP                0x0211	// rmm5700
#define WM_EXITMENULOOP                 0x0212	// rmm5700
#define WM_SIZING                       0x0214
#define WM_SETTEXT                      0x000C
#define WM_HELP                         0x0053
#define WM_MOUSEACTIVATE                0x0021
#define WM_SETICON                      0x0080
#define WM_DESTROYCLIPBOARD             0x0307
#define WM_NOTIFY												0x004E
#define WM_INSETBORDER									0x03ff
// pk6796
#define WM_PRINT												0x0317
#define WM_PRINTCLIENT      						0x0318
#define PRF_CHECKVISIBLE    						0x00000001L
#define PRF_NONCLIENT       						0x00000002L
#define PRF_CLIENT          						0x00000004L
#define PRF_ERASEBKGND      						0x00000008L
#define PRF_CHILDREN        						0x00000010L
#define PRF_OWNED           						0x00000020L

#define CW_USEDEFAULT       ((int)0x80000000)

#define LBN_DBLCLK   2

// HWND
void SetCreateTopInvisible();	// rmm7513
HWND XWindowAttach(void* xWindow,char* pClass);
BOOL XWindowDetach(HWND pHwnd);
BOOL XWindowReattach(void *pXwindow, HWND pHwnd, HWND pChildWnd);
HWND CreateWindow(char* pClass,char* pTitle,DWORD pStyle,INT pLeft,INT pTop,INT pWidth,INT pHeight,HWND pParent,HMENU pMenu,HINSTANCE pInst,LPVOID);
HWND CreateWindowEx(DWORD pExStyle,char* pClass,char* pTitle,DWORD pStyle,INT pLeft,INT pTop,INT pWidth,INT pHeight,HWND pParent,HMENU pMenu,HINSTANCE pInst,LPVOID);
BOOL GetClientRect(HWND hWnd,LPRECT lpRect);
LRESULT DefWindowProc( 	HWND pHwnd,	UINT pMessage,	WPARAM pWParam,	LPARAM pLParam ); // rmmheadless
void UpdateWindow( HWND pHwnd );
BOOL ShowWindow(HWND pHwnd,DWORD pCmdShow);
HWND SetParent( HWND pHwnd, HWND parentHwnd);
BOOL DestroyWindow(HWND pHwnd);
BOOL BringWindowToTop(HWND pHwnd);
void SetIgnoreRestack(BOOL pValue);	// rmm6006
DWORD GetTickCount();
int MapWindowPoints( HWND hWndFrom, HWND hWndTo, LPPOINT lpPoints, UINT cPoints  );
BOOL isOMNISWnd(HWND pHwnd);
HWND GetWindow(HWND pHwnd,DWORD reqType);
HWND GetParent (HWND pHwnd);
void InvalidateRect(HWND pHwnd,RECT *temp,BOOL erase);
BOOL SetWindowPos(HWND pHwnd,HWND pHwndInsertAfter,INT pLeft,INT pTop,INT pWidth,INT pHeight,DWORD pFlags);
HWND GetDesktopWindow();
void GetWindowRect(HWND pHwnd,RECT* pRect);
LRESULT OMNISCHILDWNDPROC( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam );
BOOL MoveWindow(HWND pHwnd,	INT pLeft,INT pTop,INT pWidth,INT pHeight,BOOL pRepaint);
BOOL IsWindowVisible(HWND pHwnd);
BOOL IsWindow(HWND);
// Start rmm64bit2
LONG GetWindowLong(HWND,int);
LONG SetWindowLong(HWND,int,LONG);
#ifdef is64bit
	// rmm64bitux:
	LONG_PTR GetWindowLongPtr(HWND, int);
	LONG_PTR SetWindowLongPtr(HWND, int, LONG_PTR);
	ULONG_PTR GetClassLongPtr(HWND, int);
	ULONG_PTR SetClassLongPtr(HWND, int, LONG_PTR);
#else
	#define GetWindowLongPtr GetWindowLong
	#define SetWindowLongPtr SetWindowLong	
	#define GetClassLongPtr GetClassLong
	#define SetClassLongPtr SetClassLong

	DWORD GetClassLong(HWND,int);
	LONG SetClassLong(HWND,int,LONG);
#endif
// End rmm64bit2
HWND GetTopWindow(HWND);
BOOL EnableWindow(HWND pHwnd, BOOL pEnable);
HWND WindowFromDC(HDC);

void SwapXWindows(HWND pHwnd1, HWND pHwnd2);
void NewParent(HWND pHwnd, HWND pParentHwnd);

#define HWNDTREE_TRANSPARENT 1
#define HWNDTREE_NONTRANSPARENT  2
#define HWNDTREE_ALL  (HWNDTREE_TRANSPARENT|HWNDTREE_NONTRANSPARENT)
HWND* BuildHWNDtree(HWND pHwnd,DWORD* pHwndCount,INT pType);  
void FreeHWNDtree(HWND pHwnd,HWND* pHwndTree);

#define WA_INACTIVE 0
#define WA_ACTIVE 1
#define WA_CLICKACTIVE 2
HWND GetActiveWindow();
HWND SetActiveWindow(HWND pHwnd);

BOOL IsActivateMessage();	// rmm6665

BOOL IsChild(HWND pParent,HWND pChild);
HWND GetNextWindow(HWND,int);
BOOL IsIconic(HWND);
BOOL IsZoomed(HWND);
HDC GetDC(HWND);
BOOL DeleteDC(HDC);
void DCSetDibTextColorSubstitution(HDC, BOOL);
int GetWindowText(HWND,LPTSTR,int);
BOOL SetWindowText(HWND,LPCSTR);
BOOL AdjustWindowRectEx(LPRECT,DWORD,BOOL,DWORD);
HWND WindowFromPoint(POINT);
HWND ChildWindowFromPoint(HWND hWndParent,POINT Point);
LRESULT CallWindowProc(HWND pHwnd,UINT message,WPARAM wParam,LPARAM lParam);
void GetWindowPositionOffsets(DWORD*,DWORD*);   // AE6063

#define GCL_HCURSOR					(-12)
#define GCL_WNDPROC         (-24)
#define GCLP_WNDPROC GCL_WNDPROC // rmm64bit2
int GetClassName(HWND,LPSTR,int);

#define SWP_NOSIZE          0x0001
#define SWP_NOMOVE          0x0002
#define SWP_NOZORDER        0x0004
#define SWP_NOREDRAW        0x0008
#define SWP_SHOWWINDOW      0x0040
#define SWP_HIDEWINDOW      0x0080
#define SWP_FRAMECHANGED		0x0020  // mpm4328 send when showing or hiding scrollbars
#define SWP_NOACTIVATE      0x0010
#define SWP_DRAWFRAME       SWP_FRAMECHANGED
#define SWP_DEFERERASE			0x0000 // mpm5077a

/* WNDgetWindow() relationship flags */
#define GW_HWNDFIRST        0
#define GW_HWNDLAST         1
#define GW_HWNDNEXT         2
#define GW_HWNDPREV         3
#define GW_OWNER            4
#define GW_CHILD            5
#define GW_MAX              5

#define GWL_WNDPROC         (-4)
#define GWLP_WNDPROC GWL_WNDPROC // rmm64bit2
#define GWL_STYLE           (-16)
#define GWL_ID							(-12)
#define GWL_EXSTYLE    (-20)
#define GWL_CXWINDOW				(-24)
#define GWL_FXWINDOW				(-28)
#define GWL_FRAMERECT       (-32) // MHTOOL
#define GWL_CLIENTRECT      (-34) // MHTOOL

#define HWND_TOP			((HWND)0)
#define HWND_BOTTOM		((HWND)1)

/* Special value for CreateWindow, et al. */
#define HWND_DESKTOP        ((HWND)0)			// local to most left and most top monitors edge
#define HWND_MAINWINDOW     ((HWND)1) 		// HWND_MAINWINDOW on the mac is coordinates local to the main monitor
#define HWND_MACWINDOW			((HWND)2)			// it's the macintosh window which contains the hwnd 

/* Listbox styles (used for disabling the showing and hiding of scroll bars in child windows) */
#define LBS_DISABLENOSCROLL   0x1000L

/* Basic window types */
#define WS_CHILD            0x40000000L

/* Clipping styles */
#define WS_CLIPSIBLINGS     0x04000000L
#define WS_CLIPCHILDREN     0x02000000L

/* Generic window states */
#define WS_VISIBLE          0x10000000L
#define WS_DISABLED         0x08000000L

/* Main window styles */ // mpm4023 removed WS_EX flags
#define WS_VSCROLL          0x00200000L
#define WS_HSCROLL          0x00100000L

//
#define WS_OVERLAPPED       0x00000000L
#define WS_TOPPARENT        0x00000001L
#define WS_HOSTCHILDREN     0x00000002L
#define WS_POPUP            0x80000000L
#define WS_EX_CONTEXTHELP       0x00000400L
#define WS_EX_LEFTSCROLLBAR     0x00004000L	// rmm5261: added constant // rmmunilnx3: added left scroll bar support
#define WS_CAPTION          0x00C00000L     /* WS_BORDER | WS_DLGFRAME  */
#define WS_SYSMENU          0x00080000L
#define WS_DLGFRAME         0x00400000L
#define WS_EX_ACCEPTFILES       0x00000010L
#define WS_EX_DLGMODALFRAME     0x00000001L
#define WS_EX_TRANSPARENT       0x00000020L
#define WS_BORDER           0x00800000L
#define WS_MINIMIZEBOX      0x00020000L
#define WS_MAXIMIZEBOX      0x00010000L
#define WS_THICKFRAME       0x00040000L
#define WS_SIZEBOX          WS_THICKFRAME
#define WS_EX_IGNOREMODAL	 0x20000000L
#define WS_EX_KEEPINFRONT   0x40000000L			// ae6473
#define WS_EX_OVERRIDE      0x80000000L
// Start rmm_cwo
#define WS_EX_TOOLWINDOW				0x0080L
#define WS_EX_OVERLAPPEDWINDOW	0x0300L
// End rmm_cwo

#define WS_OVERLAPPEDWINDOW (WS_OVERLAPPED     | \
                             WS_CAPTION        | \
                             WS_SYSMENU        | \
                             WS_THICKFRAME     | \
                             WS_MINIMIZEBOX    | \
                             WS_MAXIMIZEBOX)


/* WM_SETCURSOR nHittest values */
#define HTNOWHERE           0
#define HTCLIENT            1
#define HTCAPTION           2
#define HTHSCROLL           6
#define HTVSCROLL           7
#define HTBORDER            18
#define HTGROWBOX           4					// mt40180

/* Main window styles */ // mpm4023 removed WS_EX flags
#define WS_VSCROLL          0x00200000L
#define WS_HSCROLL          0x00100000L

/* Scroll bar selection constants */
#define SB_HORZ             0
#define SB_VERT             1
#define SB_TRACK						2
#define SB_BOTH             3 // MHSCROLL
#define SB_CTL              4 // MHSCROLL

/* WM_H/VSCROLL commands */
#define SB_LINEUP           0
#define SB_LINELEFT         0
#define SB_LINEDOWN         1
#define SB_LINERIGHT        1
#define SB_PAGEUP           2
#define SB_PAGELEFT         2
#define SB_PAGEDOWN         3
#define SB_PAGERIGHT        3
#define SB_THUMBPOSITION    4
#define SB_THUMBTRACK       5
#define SB_TOP              6
#define SB_LEFT             6
#define SB_BOTTOM           7
#define SB_RIGHT            7
#define SB_ENDSCROLL        8

/* WNDshowWindow() pCmdShow values */
#define HIDE_WINDOW         0
#define SW_HIDE             0
#define SW_SHOWNORMAL       1
#define SW_NORMAL           1
#define SW_SHOWMINIMIZED    2
#define SW_SHOWMAXIMIZED    3
#define SW_MAXIMIZE			3
#define SW_SHOW             5
#define SW_SHOWNOACTIVATE   4
#define SW_RESTORE          9
#define SW_SHOWNA 8
#define SW_SHOWDEFAULT			10	// rmm7790

/* supported window messages */
#define WM_NULL							0x0000
#define WM_CREATE           0x0001
#define WM_DESTROY          0x0002
#define WM_SHOWWINDOW       0x0018
#define WM_MOVE             0x0003
#define WM_SIZE             0x0005
#define WM_NCPAINT          0x0085
#define WM_PAINT            0x000F
#define WM_ERASEBKGND       0x0014
#define WM_TIMER	    			0x0113		// rmm1407
#define WM_NCMOUSEMOVE      0x00A0
#define WM_NCLBUTTONDBLCLK	0x00A3
#define WM_NCRBUTTONDBLCLK  0x00A6

#define WM_NCACTIVATE    		0x0086	// mt40029

#define WM_DROPFILES        0x0233


/* messages send by WNDsetWindowPos and others */
#define WM_WINDOWPOSCHANGING 	0x0046
#define WM_WINDOWPOSCHANGED 	0x0047
#define WM_GETMINMAXINFO			0x0048

/* Mouse input messages */
#define WM_MOUSEFIRST                   0x0200
#define WM_MOUSEMOVE        0x0200
#define WM_LBUTTONDOWN      0x0201
#define WM_LBUTTONUP        0x0202
#define WM_LBUTTONDBLCLK    0x0203
#define WM_RBUTTONDOWN      0x0204
#define WM_RBUTTONUP        0x0205
#define WM_RBUTTONDBLCLK    0x0206
#define WM_MOUSELAST                    0x0209
#define WM_CAPTURECHANGED		0x0215	// rmm_nc: Sent to the window losing the mouse capture - wParam and lParam are both zero on Linux

#define WM_NCRBUTTONUP			0x00A5 
#define WM_NCLBUTTONUP			0x00A2	// rmm1812
#define WM_NCRBUTTONDOWN    0x00A4 
#define WM_NCLBUTTONDOWN    0x00A1	// rmm1812


/* Key input messages */
#define WM_KEYFIRST                     0x0100
#define WM_KEYDOWN											0x100
#define WM_KEYUP												0x101
#define WM_KEYLAST                      0x0108

/* scroll messages */
#define WM_HSCROLL          0x0114
#define WM_VSCROLL          0x0115

/* cursor messages */
#define WM_SETCURSOR        0x0020

// mt40314 - start

/* drop file message */
#define WM_DROPFILES        0x0233

typedef struct tagNMHDR
{
    HWND  hwndFrom;
    UINT  idFrom;
    UINT  code;         // NM_ code
}   NMHDR;
typedef NMHDR FAR * LPNMHDR;

// mt40314 - end

/* base id for user generated messages */
#define WM_USER							0x0400

/* base id for external user defined messages max 0x7000 */
#define WM_EXUSER						0x2400

/* additional omnis hwnd messages range 0x7001 to 0x7FFF */
#define WM_GETERASEINFO			0x7001	// send to fld to erase areas not painted by the border
#define WM_CHILDPAINT				0x7002  // send to the parent who called WNDredrawChildren when the child is about to be painted // mpm4022
#define WM_KEYDOWNPREVIEW		0x7003	// send to parent on a WM_KEYDOWN if parent has WND_KEYPREVIEW set
#define WM_KEYUPPREVIEW			0x7004	// send to parent on a WM_KEYUP if parent has WND_KEYPREVIEW set
#define WM_BORDCALCRECT			0x7005	// send to field with custom borders when the client rect needs to be calculated ( lParam = qrect* ) // mpm4029
#define WM_BORDPAINT				0x7006	// send to field with custom borders when the border needs painting ( wParam = HDC, lParam = qrect* ) // mpm4029
#define WM_SHOWSIZEGRIP			0x7007	// send to field
#define WM_DRAGBORDER				0x7008	// PK4502 send to field wParam is 1 if it is the vertical drag bar
#define WM_FOCUSCHANGED			0x7009	// send to field when the input focus changes. wParam = 1 or 0. NOT generated by hwnd module
#define WM_ERASEBKGNDRECT		0x700A	// special erase message for erasing specified area // mpmCarbon
#define WM_GETSHADOWRECT		0x700B	// special message for returning rect for custom OSX shadows // mpmCarbon
#define WM_BORDERCHANGING		0x700C	// sent by WNDsetBorderSpec // mpm5073
#define WM_BORDERCHANGED		0x700D	// sent by WNDsetBorderSpec // mpm5073
#define WM_BORDERASEBACKGROUND 0x700E	// rmm4503: sent when painting WND_BORD_CTRL_GROUPBOX on XP
#define WM_MULTIKEYDOWNPREVIEW 0x700F	// rmmuni_mk: send to parent on a WM_MULTIKEYDOWN if parent has WND_KEYPREVIEW set (currently WM_MULTIKEYDOWN only applies to Mac OSX)
#define WM_IPHONE_ROUNDRECT_TEXTFIELDSTYLE	0x7013	// rmm_iphone13: returns qtrue if the iPhone rounded rectangle border is like that for UITextField
#define WM_COREPATTERNGRADIENTSUPPORT	0x7014	// pkgradient returns true if the object wants gradients to be shown in the pattern palette in the property inspector
#define WM_CAPTUREABORT								0x7015	// rmm_nc: sent by WNDabortMouseCapture() before it releases the capture
#define WM_OSXREPAINTPLUGIN						0x7016	// rmm_nc: tells the OSX browser plugin that it needs to repaint
// rmm6666: allocate these from the end of the range, so they do not clash with core messages (the above list starting at 0x7001)
#define WM_CLOSETOOLTIP						0x7FFD	// rmm6666: sent to HWND when tooltip needs to be closed
#define WM_OMNIS_ALLMENUS_ENABLED	0x7FFE	// rmmcups: send to main HWND to see if all menus are enabled
#define WM_OMNIS_CANCOMETOTOP			0x7FFF	// rmmcups: send to main HWND to see if window can come to the top

// Owner drawn menu messages
#define WM_DRAWITEM                     0x002B
#define WM_MEASUREITEM                  0x002C
#define WM_MENUCHAR                     0x0120


// Viewport stuff
BOOL  SetViewportOrgEx(HDC, int, int, LPPOINT);
BOOL  GetViewportOrgEx(HDC, LPPOINT);

// Line drawing
BOOL  MoveToEx(HDC, int, int, LPPOINT);
BOOL  LineTo(HDC, int, int);

// Rect stuff
BOOL EqualRect(const RECT *lprc1,const RECT *lprc2);
BOOL IsRectEmpty(const RECT *lprc);
BOOL PtInRect(const RECT *lprc,POINT pt);
BOOL	OffsetRect(LPRECT lprc,int dx,int dy);
BOOL IntersectRect(LPRECT pDst,LPRECT pSrc1,LPRECT pSrc2);
void SetRectEmpty(LPRECT pRect);
BOOL CopyRect(LPRECT lprcDst, CONST RECT *lprcSrc); // rmmunilnx3

// Text stuff
#define TA_NOUPDATECP                0
#define TA_UPDATECP                  1

#define TA_LEFT                      0
#define TA_RIGHT                     2
#define TA_CENTER                    6

#define TA_TOP                       0
#define TA_BOTTOM                    8
#define TA_BASELINE                  24
#define TA_RTLREADING								256		// mlr0039
#define TA_MASK       (TA_BASELINE+TA_CENTER+TA_UPDATECP)

/* Text Capabilities */
#define TC_OP_CHARACTER     0x00000001  /* Can do OutputPrecision   CHARACTER      */
#define TC_OP_STROKE        0x00000002  /* Can do OutputPrecision   STROKE         */
#define TC_CP_STROKE        0x00000004  /* Can do ClipPrecision     STROKE         */
#define TC_CR_90            0x00000008  /* Can do CharRotAbility    90             */
#define TC_CR_ANY           0x00000010  /* Can do CharRotAbility    ANY            */
#define TC_SF_X_YINDEP      0x00000020  /* Can do ScaleFreedom      X_YINDEPENDENT */
#define TC_SA_DOUBLE        0x00000040  /* Can do ScaleAbility      DOUBLE         */
#define TC_SA_INTEGER       0x00000080  /* Can do ScaleAbility      INTEGER        */
#define TC_SA_CONTIN        0x00000100  /* Can do ScaleAbility      CONTINUOUS     */
#define TC_EA_DOUBLE        0x00000200  /* Can do EmboldenAbility   DOUBLE         */
#define TC_IA_ABLE          0x00000400  /* Can do ItalisizeAbility  ABLE           */
#define TC_UA_ABLE          0x00000800  /* Can do UnderlineAbility  ABLE           */
#define TC_SO_ABLE          0x00001000  /* Can do StrikeOutAbility  ABLE           */
#define TC_RA_ABLE          0x00002000  /* Can do RasterFontAble    ABLE           */
#define TC_VA_ABLE          0x00004000  /* Can do VectorFontAble    ABLE           */
#define TC_RESERVED         0x00008000
#define TC_SCROLLBLT        0x00010000  /* Don't do text scroll with blt           */

BOOL  GetTextExtentPoint32(HDC,LPCSTR,int,LPSIZE);

#define PALETTERGB(r,g,b)   (0x02000000 | RGB(r,g,b))
#define RGB(r,g,b)          ((COLORREF)(((BYTE)(r)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(b))<<16)))
DWORD GetTextColor(HDC pHdc);
DWORD SetTextColor(HDC pHdc,DWORD pColor);
DWORD SetBkColor(HDC pHdc,DWORD pNewCol);
DWORD GetBkColor(HDC pHdc);
UINT  GetXColor(COLORREF pCol);
COLORREF GetWinColor(UINT pXCol);

void SetCursor( HCURSOR pCursor );
HCURSOR LoadCursor( HINSTANCE pInst, LPCTSTR cname );
HCURSOR CreateCursor(HINSTANCE pInst,int pHotX,int pHotY,int pWid,int pHt,LPBYTE pAndBits,LPBYTE pXorBits);
void DestroyCursor(HCURSOR pCursor );

HDC GetWindowDC( HWND pHwnd );
void ReleaseDC( HWND pHwnd, HDC hdc );

void InflateRect( RECT* pRect, INT pXAmt, INT pYAmt );
void FillRect( HDC pHdc, RECT* pRect, HBRUSH pBrush);
void FrameRect( HDC pHdc, RECT* pRect, HBRUSH pBrush );
void DrawFocusRect( HDC pHdc, RECT* pRect );
HWND SetFocus(HWND);
HWND GetFocus();
BOOL RectInRegion( HRGN pRgn, RECT* pRect );

void RedrawWindow(HWND pHwnd,RECT* pRect, HRGN pRgn,DWORD pFlags);
void TextOut( HDC pHdc,LONG,LONG,LPTSTR,LONG);
void DrawAccelText(HDC pHdc,LONG,LONG,LONG,LPTSTR,LONG);

int GetClipBox(HDC, LPRECT );

#define WINBASEAPI
#define MAX_COMPUTERNAME_LENGTH 15

WINBASEAPI
BOOL
WINAPI
GetComputerName (
    LPSTR lpBuffer,
    LPDWORD nSize
    );

WINBASEAPI
OMTHREADID // rmm9567
WINAPI
GetCurrentThreadId(
    VOID
    );

// I/O
typedef struct tagDCB
{
  DWORD DCBlength;
  DWORD BaudRate;
  DWORD fBinary:1;
  DWORD fParity:1;
  DWORD fOutxCtsFlow:1;
  DWORD fOutxDsrFlow:1;
  DWORD fDtrControl:2;
  DWORD fDsrSensitivity:1;
  DWORD fTXContinueOnXoff:1;
  DWORD fOutX:1;
  DWORD fInX:1;
  DWORD fErrorChar:1;
  DWORD fNull:1;
  DWORD fRtsControl:2;
  DWORD fAbortOnError:1;
  DWORD fDummy2:17;
  WORD wReserved;
  WORD XonLim;
  WORD XoffLim;
  BYTE ByteSize;
  BYTE Parity;
  BYTE StopBits;
  char XonChar;
  char XoffChar;
  char ErrorChar;
  char EofChar;
  char EvtChar;
} DCB, *LPDCB;

#define GENERIC_READ                (0x80000000) /* from WINNT.H */
#define GENERIC_WRITE               (0x40000000) /* from WINNT.H */
#define FILE_SHARE_READ             (0x00000001) /* from WINNT.H */
#define FILE_SHARE_WRITE            (0x00000002) /* from WINNT.H */
#define FILE_BEGIN                  0
#define FILE_CURRENT                1
#define FILE_END                    2

#define FILE_ATTRIBUTE_READONLY         0x00000001
#define FILE_ATTRIBUTE_HIDDEN           0x00000002
#define FILE_ATTRIBUTE_SYSTEM           0x00000004
#define FILE_ATTRIBUTE_DIRECTORY        0x00000010
#define FILE_ATTRIBUTE_ARCHIVE          0x00000020
#define FILE_ATTRIBUTE_NORMAL           0x00000080
#define FILE_ATTRIBUTE_TEMPORARY        0x00000100
#define FILE_ATTRIBUTE_COMPRESSED       0x00000800  
#define FILE_ATTRIBUTE_OFFLINE          0x00001000  


#define IE_BADID            (-1)    // Invalid or unsupported id
#define IE_OPEN             (-2)    // Device Already Open
#define IE_NOPEN            (-3)    // Device Not Open
#define IE_MEMORY           (-4)    // Unable to allocate queues
#define IE_DEFAULT          (-5)    // Error in default parameters
#define IE_HARDWARE         (-10)   // Hardware Not Present
#define IE_BYTESIZE         (-11)   // Illegal Byte Size
#define IE_BAUDRATE         (-12)   // Unsupported BaudRate

// MHCOMM begins.
// DTR Control Flow Values.
//
#define DTR_CONTROL_DISABLE    0x00
#define DTR_CONTROL_ENABLE     0x01
#define DTR_CONTROL_HANDSHAKE  0x02

//
// RTS Control Flow Values
//
#define RTS_CONTROL_DISABLE    0x00
#define RTS_CONTROL_ENABLE     0x01
#define RTS_CONTROL_HANDSHAKE  0x02
#define RTS_CONTROL_TOGGLE     0x03
// MHCOMM ends.

#define NOPARITY            0
#define ODDPARITY           1
#define EVENPARITY          2
// MHCOMM begins
#define MARKPARITY          3
#define SPACEPARITY         4

#define ONESTOPBIT          0
#define ONE5STOPBITS        1
#define TWOSTOPBITS         2
// MHCOMM ends.

//
// Baud rates at which the communication device operates
//
// MHCOMM begins.
#define CBR_110             110
#define CBR_300             300
#define CBR_600             600
#define CBR_1200            1200
#define CBR_2400            2400
#define CBR_4800            4800
#define CBR_9600            9600
#define CBR_14400           14400
#define CBR_19200           19200
#define CBR_38400           38400
#define CBR_56000           56000
#define CBR_57600           57600
#define CBR_115200          115200
#define CBR_128000          128000
#define CBR_256000          256000
#define CBR_230400          230400
// MHCOMM ends.

#define OF_READ             0x00000000

#define CREATE_NEW          1
#define CREATE_ALWAYS       2
#define OPEN_EXISTING       3
#define OPEN_ALWAYS         4

#define FILE_FLAG_RANDOM_ACCESS         0x10000000

#define PURGE_TXABORT       0x0001  // Kill the pending/current writes to the comm port.
#define PURGE_RXABORT       0x0002  // Kill the pending/current reads to the comm port.
#define PURGE_TXCLEAR       0x0004  // Kill the transmit queue if there.
#define PURGE_RXCLEAR       0x0008  // Kill the typeahead buffer if there.

// MHCOMM begins.
#define PST_UNSPECIFIED      ((DWORD)0x00000000)
#define PST_RS232            ((DWORD)0x00000001)
#define PST_PARALLELPORT     ((DWORD)0x00000002)
#define PST_RS422            ((DWORD)0x00000003)
#define PST_RS423            ((DWORD)0x00000004)
#define PST_RS449            ((DWORD)0x00000005)
#define PST_MODEM            ((DWORD)0x00000006)
#define PST_FAX              ((DWORD)0x00000021)
#define PST_SCANNER          ((DWORD)0x00000022)
// MHCOMM ends.

typedef struct tagCOMMTIMEOUTS
{
int ReadIntervalTimeout;
int ReadTotalTimeoutMultiplier;
int ReadTotalTimeoutConstant;
int WriteTotalTimeroutMultiplier;
int WriteTotalTimeoutConstant;
int WriteTotalTimeoutMultiplier;
} COMMTIMEOUTS, *LPCOMMTIMEOUTS;
typedef struct tagCOMMPROP
{
  int dwCurrentRxQueue;
  int dwProvSubType;
} COMMPROP, *LPCOMMPROP;

typedef struct tagFILETIME
{
    DWORD dwLowDateTime;
    DWORD dwHighDateTime;
} FILETIME,*LPFILETIME;
typedef struct tagWIN32_FIND_DATA
{
    DWORD       dwFileAttributes;
    FILETIME    ftCreationTime;
    FILETIME    ftLastAccessTime;
    FILETIME    ftLastWriteTime;
    DWORD       nFileSizeHigh;
    DWORD       nFileSizeLow;
    DWORD       dwReserved0;
    DWORD       dwReserved1;
    TCHAR        cFileName[ MAX_PATH ];
    TCHAR        cAlternateFileName[ 16 ];
} WIN32_FIND_DATA, *LPWIN32_FIND_DATA;
#define FILE_ATTRIBUTE_NORMAL           0x00000080  
#define FILE_ATTRIBUTE_READONLY         0x00000001
#define DRIVE_REMOVABLE 2  
HANDLE FindFirstFile(LPCSTR,LPWIN32_FIND_DATA);
BOOL FindClose(HANDLE);
BOOL SetCurrentDirectory(LPCSTR);
BOOL CreateDirectory(LPCSTR lpPathName, LPVOID lpSecurityAttributes);
HANDLE CreateFile(LPCSTR lpFileName,DWORD dwDesiredAccess,DWORD dwShareMode,LPVOID lpSecurityAttributes,DWORD dwCreationDisposition,DWORD dwFlagsAndAttributes,HANDLE hTemplateFile);
BOOL ReadFile(HANDLE hFile,LPVOID lpBuffer,DWORD nNumberOfBytesToRead,LPDWORD lpNumberOfBytesRead,LPVOID lpOverlapped);
BOOL WriteFile(HANDLE hFile,LPVOID lpBuffer,DWORD nNumberOfBytesToWrite,LPDWORD lpNumberOfBytesWritten,LPVOID lpOverlapped);
BOOL WINAPI CopyFile(LPCSTR szSrc, LPCSTR szDst, BOOL fFailIfExists); // MHUX002
BOOL WINAPI MoveFile(LPCSTR lpExistingFileName, LPCSTR lpNewFileName); // MHUX002
VOID splitpath(LPCSTR path, LPSTR drive, LPSTR directory, LPSTR filename, LPSTR extension ); // MHUX002
UINT GetDriveType(LPCTSTR lpRootPathName); // MHUX002
DWORD GetLogicalDrives(VOID); // MHUX002
BOOL GetDiskFreeSpace(LPTSTR lpszPath,LPDWORD sectorsPerCluster,LPDWORD bytesPerSector,LPDWORD freeCluster,LPDWORD clusters);
BOOL GetVolumeInformation(LPCTSTR lpRootPathName, LPTSTR lpVolumeNameBuffer, DWORD nVolumeNameSize,
													LPDWORD lpVolumeSerialNumber, LPDWORD lpMaximumComponentLength,
													LPDWORD lpFileSystemFlags, LPTSTR lpFileSystemNameBuffer,
													DWORD nFileSystemNameSize); // MHUX002
BOOL DoesFileExist(LPCTSTR pFileName);
DWORD GetFileAttributes(LPCTSTR lpFileName);												// rmm5564
BOOL SetFileAttributes(LPCTSTR lpFileName, DWORD dwFileAttributes); // rmm5564
BOOL RemoveDirectory(LPCTSTR lpPathName);

// MHUX002 begins.
#define	_tsplitpath		_splitpath
#define     _splitpath(la,lb,lc,ld,le)         \
            (splitpath(la,lb,lc,ld,le)) 
// MHUX002 ends. 
typedef struct tagTheMess
{
    LONG message;
} TheMess;
typedef struct tagMSG
{
    HWND        hwnd;
    UINT        message;
    WPARAM      wParam;
    LPARAM      lParam;
    DWORD       time;
    POINT       pt;
} MSG,*LPMSG;


typedef void* HGLOBAL;
typedef void* GLOBALHANDLE;
typedef void* HRSRC;
typedef void* TIMERPROC;


#define INVALID_HANDLE_VALUE (HANDLE)-1

#define CP_WINANSI      1004    /* default codepage for windows & old DDE convs. */

#define CF_TEXT             1
#define CF_BITMAP           2
#define CF_METAFILEPICT     3
#define CF_SYLK             4
#define CF_DIF              5
#define CF_TIFF             6
#define CF_OEMTEXT          7
#define CF_DIB              8
#define CF_PALETTE          9
#define CF_PENDATA          10
#define CF_RIFF             11
#define CF_WAVE             12
#define CF_UNICODETEXT      13
#define CF_ENHMETAFILE      14
#define CF_HDROP            15
#define CF_LOCALE           16
#define CF_MAX              17
#define CF_OWNERDISPLAY     0x0080
#define CF_DSPTEXT          0x0081
#define CF_DSPBITMAP        0x0082
#define CF_DSPMETAFILEPICT  0x0083
#define CF_DSPENHMETAFILE   0x008E

#define COLORONCOLOR                 3
#define PROCESSOR_INTEL_386     386
#define PROCESSOR_INTEL_486     486
#define PROCESSOR_INTEL_PENTIUM 586
#define EXPORT

// to ole.h?
typedef struct tagSMALL_RECT
{
    short Left;
    short Top;
    short Right;
    short Bottom;
} SMALL_RECT;

typedef struct tagMETAFILEPICT
{
  int xExt;
  int yExt;
  int mm;
  HMETAFILE hMF;
} METAFILEPICT,*LPMETAFILEPICT;

typedef struct tagENHMETAHEADER
{
  DWORD nSize;
  RECT rclFrame;
  RECT rclBounds;

} ENHMETAHEADER,*LPENHMETAHEADER;

typedef struct tagMEMORYSTATUS
{
  DWORD dwLength;
  DWORD dwMemoryLoad;
  DWORD dwTotalPhys;
  DWORD dwAvailPhys;
  DWORD dwTotalPageFile;
  DWORD dwAvailPageFile;
  DWORD dwTotalVirtual;
  DWORD dwAvailVirtual;
	 DWORD dwDBGallocCount;
	 DWORD dwDBGallocMemory;
} MEMORYSTATUS;
void GlobalMemoryStatus(MEMORYSTATUS*);

typedef struct tagSYSTEM_INFO
{
  DWORD dwProcessorType;
  DWORD dwNumberOfProcessors;
  WORD wProcessorRevision;
WORD wProcessorLevel;
} SYSTEM_INFO;
void GetSystemInfo(SYSTEM_INFO* sSysInf);

typedef struct tagSYSTEMTIME
{
  WORD wYear;
  WORD wMonth;
  WORD wDayOfWeek;
  WORD wDay;
  WORD wHour;
  WORD wMinute;
  WORD wSecond;
  WORD wMilliseconds;
} SYSTEMTIME,*LPSYSTEMTIME;

typedef struct _TIME_ZONE_INFORMATION {
 LONG Bias;
 TCHAR StandardName[32];
 SYSTEMTIME StandardDate;
 LONG StandardBias;
 TCHAR DaylightName[32];
 SYSTEMTIME DaylightDate;
 LONG DaylightBias;
} TIME_ZONE_INFORMATION, *PTIME_ZONE_INFORMATION, *LPTIME_ZONE_INFORMATION;

void GetLocalTime(SYSTEMTIME*);
void GetLocalTimeWithOffset(SYSTEMTIME*, int pTimeOffsetInSeconds);	// rmm9008
void GetSystemTime(SYSTEMTIME*);

// DeviceCaps
#define TECHNOLOGY    2     /* Device classification                    */
#define HORZSIZE      4     /* Horizontal size in millimeters           */
#define VERTSIZE      6     /* Vertical size in millimeters             */
#define HORZRES       8     /* Horizontal width in pixels               */
#define VERTRES       10    /* Vertical height in pixels                */
#define RASTERCAPS    38    /* Bitblt capabilities                      */
#define LOGPIXELSX    88    /* Logical pixels/inch in X                 */
#define LOGPIXELSY    90    /* Logical pixels/inch in Y                 */
#define BITSPIXEL     12    /* Number of bits per pixel                 */
#define SIZEPALETTE  104    /* Number of entries in physical palette    */
#define NUMRESERVED  106    /* Number of reserved entries in palette    */
int GetDeviceCaps(HDC hdc,int index);

// SystemMetrics
#define SM_CXBORDER          5
#define SM_CYBORDER          6
#define SM_CXCURSOR             13
#define SM_CYCURSOR             14
#define SM_SWAPBUTTON           23
#define SM_CYVSCROLL            20
#define SM_CXHSCROLL            21
#define SM_CXVSCROLL            2
#define SM_CYHSCROLL            3
#define SM_CYMENU               15
#define SM_MOUSEPRESENT         19
#define SM_CXDLGFRAME           7
#define SM_CYDLGFRAME           8
#define SM_CXSCREEN             0
#define SM_CYSCREEN             1
#define SM_CYCAPTION            4
#define SM_CXFRAME              32
#define SM_CYFRAME              33
#define SM_CXMINTRACK			34
#define SM_CYMINTRACK			35
#define SM_CXICON               11
#define SM_CYICON               12
#define SM_CXSMICON             49
#define SM_CYSMICON             50
// Start rmm8706: These values are never used in a call, but are needed for the core to compile
#define SM_CXEDGE								45
#define SM_CYEDGE								46
#define SM_CYSMCAPTION					51
// End rmm8706
#define SM_CXSIZEFRAME            SM_CXFRAME     /* ;win40 name change */
#define SM_CYSIZEFRAME            SM_CYFRAME     /* ;win40 name change */
#define SM_FILECASEMODE					1000
#define SM_PRINTER_XMARGIN 			1001	// rmm3730
#define SM_PRINTER_YMARGIN 			1002	// rmm3730


int GetSystemMetrics(int);

#define __cdecl 
#define __fastcall                  // Only for xasm.h GetDosVersion
void GetCursorPos(LPPOINT);
void GetClientCursorPos(HWND pParentHwnd, HWND pHwnd, LPPOINT pPoint);		// rmm6202: makes WM_NULL reliable on the Web client
void SetCursorPos(UINT,UINT);
UINT SetTimer(HWND,UINT,DWORD,FARPROC);
UINT KillTimer(HWND,UINT);
BOOL ExpireTimers();
void Sleep(DWORD dwMilliseconds);	// rmm3941
BOOL IsValidTimerProc(FARPROC pTimerProc);
void ClipCursor(LPRECT);
#define OBJ_PEN             1
#define OBJ_BRUSH           2
#define OBJ_DC              3
#define OBJ_METADC          4
#define OBJ_PAL             5
#define OBJ_FONT            6
#define OBJ_BITMAP          7
#define OBJ_REGION          8
#define OBJ_METAFILE        9
#define OBJ_MEMDC           10
#define OBJ_EXTPEN          11
#define OBJ_ENHMETADC       12
#define OBJ_ENHMETAFILE     13
DWORD GetObjectType(HGDIOBJ);
int GetObject( HGDIOBJ, int,void*);	// rmm64bitux: Corrected return value from void * to int
void SetTextAlign(HDC,int);

// String functions
char* lstrcat(char*,const char*);
char* lstrcpy(char*,const char*);
int lstrcmpi(const char*,const char*);
int lstrcmp(const char*,const char*);
int lstrlen(const char*);
int lstrncmpi(const char*,const char*,int len);
LPSTR AnsiUpper(LPSTR);
int lstrcpyn(char*,const char*,int len);
int wsprintf(LPTSTR lpOut, LPCTSTR lpFmt,...);

// Clipboard
BOOL OpenClipboard(HWND);
BOOL CloseClipboard();
HANDLE SetClipboardData(UINT uFormat,HANDLE hMem);
HANDLE GetClipboardData(UINT uFormat);
BOOL	EmptyClipboard();
BOOL IsClipboardFormatAvailable(UINT uFormat);

// Virtual keys
#define VK_LBUTTON        0x01
#define VK_RBUTTON        0x02
#define VK_CANCEL         0x03
#define VK_MBUTTON        0x04    /* NOT contiguous with L & RBUTTON */

#define VK_BACK           0x08
#define VK_TAB            0x09

#define VK_CLEAR          0x0C
#define VK_RETURN         0x0D

#define VK_SHIFT          0x10
#define VK_CONTROL        0x11
#define VK_MENU           0x12
#define VK_PAUSE          0x13
#define VK_CAPITAL        0x14


#define VK_ESCAPE         0x1B

#define VK_SPACE          0x20
#define VK_PRIOR          0x21
#define VK_NEXT           0x22
#define VK_END            0x23
#define VK_HOME           0x24
#define VK_LEFT           0x25
#define VK_UP             0x26
#define VK_RIGHT          0x27
#define VK_DOWN           0x28
#define VK_SELECT         0x29
#define VK_PRINT          0x2A
#define VK_EXECUTE        0x2B
#define VK_SNAPSHOT       0x2C
#define VK_INSERT         0x2D
#define VK_DELETE         0x2E
#define VK_HELP           0x2F

/* VK_0 thru VK_9 are the same as ASCII '0' thru '9' (0x30 - 0x39) */
/* VK_A thru VK_Z are the same as ASCII 'A' thru 'Z' (0x41 - 0x5A) */

#define VK_LWIN           0x5B
#define VK_RWIN           0x5C
#define VK_APPS           0x5D

#define VK_NUMPAD0        0x60
#define VK_NUMPAD1        0x61
#define VK_NUMPAD2        0x62
#define VK_NUMPAD3        0x63
#define VK_NUMPAD4        0x64
#define VK_NUMPAD5        0x65
#define VK_NUMPAD6        0x66
#define VK_NUMPAD7        0x67
#define VK_NUMPAD8        0x68
#define VK_NUMPAD9        0x69
#define VK_MULTIPLY       0x6A
#define VK_ADD            0x6B
#define VK_SEPARATOR      0x6C
#define VK_SUBTRACT       0x6D
#define VK_DECIMAL        0x6E
#define VK_DIVIDE         0x6F
#define VK_F1             0x70
#define VK_F2             0x71
#define VK_F3             0x72
#define VK_F4             0x73
#define VK_F5             0x74
#define VK_F6             0x75
#define VK_F7             0x76
#define VK_F8             0x77
#define VK_F9             0x78
#define VK_F10            0x79
#define VK_F11            0x7A
#define VK_F12            0x7B
#define VK_F13            0x7C
#define VK_F14            0x7D
#define VK_F15            0x7E
#define VK_F16            0x7F
#define VK_F17            0x80
#define VK_F18            0x81
#define VK_F19            0x82
#define VK_F20            0x83
#define VK_F21            0x84
#define VK_F22            0x85
#define VK_F23            0x86
#define VK_F24            0x87
#define VK_NUMLOCK        0x90
#define VK_SCROLL         0x91
#define VK_LSHIFT         0xA0
#define VK_RSHIFT         0xA1
#define VK_LCONTROL       0xA2
#define VK_RCONTROL       0xA3
#define VK_LMENU          0xA4
#define VK_RMENU          0xA5


// Messagebox flags
#define MB_APPLMODAL                0x00000000L
#define MB_SYSTEMMODAL              0x00001000L
#define MB_TASKMODAL                0x00002000L
#define MB_NORMALFRAME							0x00004000L
#define MB_NOWAIT                   0x40000000L
#define MB_NOBUTTONS                0x20000000L
#define MB_OK                       0x00000000L
#define MB_OKCANCEL                 0x00000001L
#define MB_ABORTRETRYIGNORE         0x00000002L
#define MB_YESNOCANCEL              0x00000003L
#define MB_YESNO                    0x00000004L
#define MB_RETRYCANCEL              0x00000005L
#define MB_ICONHAND                 0x00000010L
#define MB_ICONQUESTION             0x00000020L
#define MB_ICONEXCLAMATION          0x00000030L
#define MB_ICONASTERISK             0x00000040L
#define MB_ICONSTOP                 MB_ICONHAND
#define MB_ICONINFORMATION          MB_ICONASTERISK
#define MB_DEFBUTTON1               0x00000000L
#define MB_DEFBUTTON2               0x00000100L
#define MB_DEFBUTTON3               0x00000200L
int MessageBox(HWND,LPCSTR,LPCSTR,UINT);

// Printer
typedef struct tagDEVNAMES
{
  WORD wDriverOffset;
  WORD wDeviceOffset;
  WORD wOutputOffset;
  WORD wDefault;
} DEVNAMES, *LPDEVNAMES;

typedef struct tagPRINTDLG
{
  DWORD lStructSize;
  HWND hwndOwner;
  HANDLE hDevMode;
  HANDLE hDevNames;
  HDC hDC;
  DWORD Flags;
  WORD nFromPage;
  WORD nToPage;
  WORD nMinPage;
  WORD nMaxPage;
  WORD nCopies;
  HINSTANCE hInstance;
  DWORD lCustData;
  FARPROC lpfnSetupHook;
} PRINTDLG, *LPPRINTDLG;

typedef struct tagJOBSETUPDLG
{
	HGLOBAL hDevMode;	// Must be supplied; updated by API
	HGLOBAL	hPages;		// If supplied as zero, all pages are to be printed; otherwise, this contains the page ranges etc (syntax as required by the dialog) - a null terminated string
										// Returned using same convention.
	DWORD		jsCopies;	// Number of copies (input and output field)
} JOBSETUPDLG, *LPJOBSETUPDLG;

// rmmcups: Banner constants
#define DMBANNER_NONE					0
#define DMBANNER_CLASSIFIED		1
#define DMBANNER_CONFIDENTIAL 2
#define DMBANNER_SECRET				3
#define DMBANNER_STANDARD			4
#define DMBANNER_TOPSECRET		5
#define DMBANNER_UNCLASSIFIED	6

// Banner option values passed to the lp command
#define PRI_BANNER_STR_NONE					"none"
#define PRI_BANNER_STR_CLASSIFIED		"classified"
#define PRI_BANNER_STR_CONFIDENTIAL "confidential"
#define PRI_BANNER_STR_SECRET				"secret"
#define PRI_BANNER_STR_STANDARD			"standard"
#define PRI_BANNER_STR_TOPSECRET		"topsecret"
#define PRI_BANNER_STR_UNCLASSIFIED	"unclassified"

// Standard PPD option values
#define PPD_OPT_DUPLEX									"Duplex"
#define PPD_OPT_INPUTSLOT								"InputSlot"
#define PPD_OPT_PAGEREGION							"PageRegion"
#define PPD_OPT_PAGESIZE								"PageSize"

typedef struct tagDEVMODE
{
  TCHAR dmDeviceName[128];			// rmmcups: increased from 32 to 128, to allow for UTF-8
	TCHAR	dmManufacturer[128];		// rmmcups
	TCHAR	dmPrinterModel[128];		// rmmcups
  WORD dmSpecVersion;
  WORD dmDriverVersion;
  WORD dmSize;
  WORD dmDriverExtra;
  DWORD dmFields;
  short dmOrientation;
  short dmPaperSize;
  short dmPaperLength;
  short dmPaperWidth;
  short dmScale;
  short dmCopies;
  short dmDefaultSource;
  short dmPrintQuality;
  short dmColor;
  short dmDuplex;
  short dmYResolution;
  short dmTTOption;
  short dmCollate;
  TCHAR dmSpare[32];					// rmmcups: dmFormName in the windows DEVMODE - keep this for future changes
  WORD dwUnusedPadding;
  USHORT dmBitsPerPel;
  DWORD dmPelsWidth;
  DWORD dmPelsHeight;
  DWORD dmDisplayFlags;
  DWORD dmDisplayFrequency;
  DWORD dmICMMethod;					// rmmcups: added this and the remaining items to the structure
  DWORD dmICMIntent;
  DWORD dmMediaType;
  DWORD dmDitherType;
  DWORD dmReserved1;
  DWORD dmReserved2;
  DWORD dmPanningWidth;
  DWORD dmPanningHeight;
	int		mBannerBefore;	// DMBANNER_... value, identifying the pre-job banner
	int		mBannerAfter;		// DMBANNER_... value, identifying the post-job banner
} DEVMODE, *LPDEVMODE, *PDEVMODE;

#define DM_SPECVERSION 0x4001		// rmmcups

#define PRINTER_ACCESS_USE      0x00000008

// Device capabilities
#define DC_FIELDS								1
#define DC_PAPERS								2
#define DC_PAPERSIZE						3
#define DC_MINEXTENT						4
#define DC_MAXEXTENT						5
#define DC_BINS									6
#define DC_DUPLEX								7
#define DC_SIZE									8
#define DC_EXTRA								9
#define DC_VERSION							10
#define DC_DRIVER								11
#define DC_BINNAMES							12
#define DC_ENUMRESOLUTIONS			13
#define DC_FILEDEPENDENCIES			14
#define DC_TRUETYPE							15
#define DC_PAPERNAMES						16
#define DC_ORIENTATION					17
#define DC_COPIES								18
#define DC_BINADJUST            19
#define DC_EMF_COMPLIANT        20
#define DC_DATATYPE_PRODUCED    21
#define DC_COLLATE              22
#define DC_MANUFACTURER         23
#define DC_MODEL                24
#define DC_PERSONALITY          25
#define DC_PRINTRATE            26
#define DC_PRINTRATEUNIT        27
#define   PRINTRATEUNIT_PPM     1
#define   PRINTRATEUNIT_CPS     2
#define   PRINTRATEUNIT_LPM     3
#define   PRINTRATEUNIT_IPM     4
#define DC_PRINTERMEM           28
#define DC_MEDIAREADY           29
#define DC_STAPLE               30
#define DC_PRINTRATEPPM         31
#define DC_COLORDEVICE          32
#define DC_NUP                  33
#define DC_MEDIATYPENAMES       34
#define DC_MEDIATYPES           35
#define DC_MARGINS							36	// rmmcups

#define DMORIENT_PORTRAIT				1
#define DMORIENT_LANDSCAPE			2

#define DM_ORIENTATION					0x00000001L
#define DM_PAPERSIZE						0x00000002L
#define DM_PAPERLENGTH					0x00000004L
#define DM_PAPERWIDTH						0x00000008L
#define DM_SCALE								0x00000010L
#define DM_POSITION             0x00000020L
#define DM_NUP                  0x00000040L
#define DM_DISPLAYORIENTATION   0x00000080L
#define DM_COPIES								0x00000100L
#define DM_DEFAULTSOURCE				0x00000200L
#define DM_PRINTQUALITY         0x00000400L
#define DM_COLOR                0x00000800L
#define DM_DUPLEX               0x00001000L
#define DM_YRESOLUTION          0x00002000L
#define DM_TTOPTION             0x00004000L
#define DM_COLLATE              0x00008000L
#define DM_FORMNAME             0x00010000L
#define DM_LOGPIXELS            0x00020000L
#define DM_BITSPERPEL           0x00040000L
#define DM_PELSWIDTH            0x00080000L
#define DM_PELSHEIGHT           0x00100000L
#define DM_DISPLAYFLAGS         0x00200000L
#define DM_DISPLAYFREQUENCY     0x00400000L
#define DM_ICMMETHOD            0x00800000L
#define DM_ICMINTENT            0x01000000L
#define DM_MEDIATYPE            0x02000000L
#define DM_DITHERTYPE           0x04000000L
#define DM_PANNINGWIDTH         0x08000000L
#define DM_PANNINGHEIGHT        0x10000000L
#define DM_DISPLAYFIXEDOUTPUT   0x20000000L

#define DMCOLOR_MONOCHROME  1
#define DMCOLOR_COLOR       2

#define DMDUP_SIMPLEX				1
#define DMDUP_VERTICAL			2
#define DMDUP_HORIZONTAL		3

#define DMCOLLATE_FALSE			0
#define DMCOLLATE_TRUE			1

#define DMMEDIA_STANDARD      1
#define DMMEDIA_TRANSPARENCY  2
#define DMMEDIA_GLOSSY        3
#define DMMEDIA_USER        256

#define DM_PROMPT								1
#define DM_IN_PROMPT						DM_PROMPT
#define DM_IN_BUFFER						8
#define DM_OUT_BUFFER						2
#define NEXTBAND                3
typedef struct _DOCINFO {
    int     cbSize;
    LPCSTR   lpszDocName;
    LPCSTR   lpszOutput;
    LPCSTR   lpszDatatype;
    DWORD    fwType;
} DOCINFO, *LPDOCINFO;

#define DC_FIELDS						1
#define DC_BINNAMES         12
#define DC_BINS             6
#define DC_COPIES						18
typedef struct _PRINTER_INFO_2
{
  char *pPrinterName;
} PRINTER_INFO_2;

typedef struct tagPRINTER_DEFAULTS
{
  int DesiredAccess;

} PRINTER_DEFAULTS, *LPPRINTER_DEFAULTS;
#define PD_RETURNDC 1
#define PD_USEDEVMODECOPIES 2
#define PD_PRINTSETUP 4
#define PD_NOPAGENUMS 8
#define PD_SHOWHELP 16
#define PD_ENABLESETUPHOOK 32
#define PHYSICALOFFSETX 1
#define PHYSICALOFFSETY 2

// rmm_cups: paper sizes
/* paper selections */
#define DMPAPER_FIRST                DMPAPER_LETTER
#define DMPAPER_LETTER               1  // Letter 8 1/2 x 11 in
#define DMPAPER_LETTERSMALL          2  // Letter Small 8 1/2 x 11 in
#define DMPAPER_TABLOID              3  // Tabloid 11 x 17 in
#define DMPAPER_LEDGER               4  // Ledger 17 x 11 in
#define DMPAPER_LEGAL                5  // Legal 8 1/2 x 14 in
#define DMPAPER_STATEMENT            6  // Statement 5 1/2 x 8 1/2 in
#define DMPAPER_EXECUTIVE            7  // Executive 7 1/4 x 10 1/2 in
#define DMPAPER_A3                   8  // A3 297 x 420 mm
#define DMPAPER_A4                   9  // A4 210 x 297 mm
#define DMPAPER_A4SMALL             10  // A4 Small 210 x 297 mm
#define DMPAPER_A5                  11  // A5 148 x 210 mm
#define DMPAPER_B4                  12  // B4 (JIS) 250 x 35
#define DMPAPER_B5                  13  // B5 (JIS) 182 x 257 mm
#define DMPAPER_FOLIO               14  // Folio 8 1/2 x 13 in
#define DMPAPER_QUARTO              15  // Quarto 215 x 275 mm
#define DMPAPER_10X14               16  // 10x14 in
#define DMPAPER_11X17               17  // 11x17 in
#define DMPAPER_NOTE                18  // Note 8 1/2 x 11 in
#define DMPAPER_ENV_9               19  // Envelope #9 3 7/8 x 8 7/8 
#define DMPAPER_ENV_10              20  // Envelope #10 4 1/8 x 9 1/2 
#define DMPAPER_ENV_11              21  // Envelope #11 4 1/2 x 10 3/8 
#define DMPAPER_ENV_12              22  // Envelope #12 4 \276 x 11
#define DMPAPER_ENV_14              23  // Envelope #14 5 x 11 1/2 
#define DMPAPER_CSHEET              24  // C size sh
#define DMPAPER_DSHEET              25  // D size sh
#define DMPAPER_ESHEET              26  // E size sh
#define DMPAPER_ENV_DL              27  // Envelope DL 110 x 22
#define DMPAPER_ENV_C5              28  // Envelope C5 162 x 229 mm
#define DMPAPER_ENV_C3              29  // Envelope C3  324 x 458 mm
#define DMPAPER_ENV_C4              30  // Envelope C4  229 x 324 mm
#define DMPAPER_ENV_C6              31  // Envelope C6  114 x 162 mm
#define DMPAPER_ENV_C65             32  // Envelope C65 114 x 229 mm
#define DMPAPER_ENV_B4              33  // Envelope B4  250 x 353 mm
#define DMPAPER_ENV_B5              34  // Envelope B5  176 x 250 mm
#define DMPAPER_ENV_B6              35  // Envelope B6  176 x 125 mm
#define DMPAPER_ENV_ITALY           36  // Envelope 110 x 230 mm
#define DMPAPER_ENV_MONARCH         37  // Envelope Monarch 3.875 x 7.5 in
#define DMPAPER_ENV_PERSONAL        38  // 6 3/4 Envelope 3 5/8 x 6 1/2 in
#define DMPAPER_FANFOLD_US          39  // US Std Fanfold 14 7/8 x 11 in
#define DMPAPER_FANFOLD_STD_GERMAN  40  // German Std Fanfold 8 1/2 x 12 in
#define DMPAPER_FANFOLD_LGL_GERMAN  41  // German Legal Fanfold 8 1/2 x 13 in
#define DMPAPER_ISO_B4              42  // B4 (ISO) 250 x 353 mm
#define DMPAPER_JAPANESE_POSTCARD   43  // Japanese Postcard 100 x 148 mm
#define DMPAPER_9X11                44  // 9 x 11 in
#define DMPAPER_10X11               45  // 10 x 11 in
#define DMPAPER_15X11               46  // 15 x 11 in
#define DMPAPER_ENV_INVITE          47  // Envelope Invite 220 x 220 mm
#define DMPAPER_RESERVED_48         48  // RESERVED--DO NOT USE
#define DMPAPER_RESERVED_49         49  // RESERVED--DO NOT USE
#define DMPAPER_LETTER_EXTRA        50  // Letter Extra 9 \275 x 12 in
#define DMPAPER_LEGAL_EXTRA         51  // Legal Extra 9 \275 x 15 in
#define DMPAPER_TABLOID_EXTRA       52  // Tabloid Extra 11.69 x 18 in
#define DMPAPER_A4_EXTRA            53  // A4 Extra 9.27 x 12.69 in
#define DMPAPER_LETTER_TRANSVERSE   54  // Letter Transverse 8 \275 x 11 in
#define DMPAPER_A4_TRANSVERSE       55  // A4 Transverse 210 x 297 mm
#define DMPAPER_LETTER_EXTRA_TRANSVERSE 56 // Letter Extra Transverse 9\275 x 12 in
#define DMPAPER_A_PLUS              57  // SuperA/SuperA/A4 227 x 356 mm
#define DMPAPER_B_PLUS              58  // SuperB/SuperB/A3 305 x 487 mm
#define DMPAPER_LETTER_PLUS         59  // Letter Plus 8.5 x 12.69 in
#define DMPAPER_A4_PLUS             60  // A4 Plus 210 x 330 mm
#define DMPAPER_A5_TRANSVERSE       61  // A5 Transverse 148 x 210 mm
#define DMPAPER_B5_TRANSVERSE       62  // B5 (JIS) Transverse 182 x 257 mm
#define DMPAPER_A3_EXTRA            63  // A3 Extra 322 x 445 mm
#define DMPAPER_A5_EXTRA            64  // A5 Extra 174 x 235 mm
#define DMPAPER_B5_EXTRA            65  // B5 (ISO) Extra 201 x 276 mm
#define DMPAPER_A2                  66  // A2 420 x 594 mm
#define DMPAPER_A3_TRANSVERSE       67  // A3 Transverse 297 x 420 mm
#define DMPAPER_A3_EXTRA_TRANSVERSE 68  // A3 Extra Transverse 322 x 445 mm
#define DMPAPER_DBL_JAPANESE_POSTCARD 69 // Japanese Double Postcard 200 x 148 mm
#define DMPAPER_A6                  70  // A6 105 x 148 mm
#define DMPAPER_JENV_KAKU2          71  // Japanese Envelope Kaku #2 
#define DMPAPER_JENV_KAKU3          72  // Japanese Envelope Kaku #3 
#define DMPAPER_JENV_CHOU3          73  // Japanese Envelope Chou #3 
#define DMPAPER_JENV_CHOU4          74  // Japanese Envelope Chou #4 
#define DMPAPER_LETTER_ROTATED      75  // Letter Rotated 11 x 8 1/2 11 in
#define DMPAPER_A3_ROTATED          76  // A3 Rotated 420 x 297 mm
#define DMPAPER_A4_ROTATED          77  // A4 Rotated 297 x 210 mm
#define DMPAPER_A5_ROTATED          78  // A5 Rotated 210 x 148 mm
#define DMPAPER_B4_JIS_ROTATED      79  // B4 (JIS) Rotated 364 x 257 mm
#define DMPAPER_B5_JIS_ROTATED      80  // B5 (JIS) Rotated 257 x 182 mm
#define DMPAPER_JAPANESE_POSTCARD_ROTATED 81 // Japanese Postcard Rotated 148 x 100 mm
#define DMPAPER_DBL_JAPANESE_POSTCARD_ROTATED 82 // Double Japanese Postcard Rotated 148 x 200 mm
#define DMPAPER_A6_ROTATED          83  // A6 Rotated 148 x 105 mm
#define DMPAPER_JENV_KAKU2_ROTATED  84  // Japanese Envelope Kaku #2 Rotated
#define DMPAPER_JENV_KAKU3_ROTATED  85  // Japanese Envelope Kaku #3 Rotated
#define DMPAPER_JENV_CHOU3_ROTATED  86  // Japanese Envelope Chou #3 Rotated
#define DMPAPER_JENV_CHOU4_ROTATED  87  // Japanese Envelope Chou #4 Rotated
#define DMPAPER_B6_JIS              88  // B6 (JIS) 128 x 182 mm
#define DMPAPER_B6_JIS_ROTATED      89  // B6 (JIS) Rotated 182 x 128 mm
#define DMPAPER_12X11               90  // 12 x 11 in
#define DMPAPER_JENV_YOU4           91  // Japanese Envelope You #4        
#define DMPAPER_JENV_YOU4_ROTATED   92  // Japanese Envelope You #4 Rotated
#define DMPAPER_P16K                93  // PRC 16K 146 x 215 mm
#define DMPAPER_P32K                94  // PRC 32K 97 x 151 mm
#define DMPAPER_P32KBIG             95  // PRC 32K(Big) 97 x 151 mm
#define DMPAPER_PENV_1              96  // PRC Envelope #1 102 x 165 mm
#define DMPAPER_PENV_2              97  // PRC Envelope #2 102 x 176 mm
#define DMPAPER_PENV_3              98  // PRC Envelope #3 125 x 176 mm
#define DMPAPER_PENV_4              99  // PRC Envelope #4 110 x 208 mm
#define DMPAPER_PENV_5              100 // PRC Envelope #5 110 x 220 mm
#define DMPAPER_PENV_6              101 // PRC Envelope #6 120 x 230 mm
#define DMPAPER_PENV_7              102 // PRC Envelope #7 160 x 230 mm
#define DMPAPER_PENV_8              103 // PRC Envelope #8 120 x 309 mm
#define DMPAPER_PENV_9              104 // PRC Envelope #9 229 x 324 mm
#define DMPAPER_PENV_10             105 // PRC Envelope #10 324 x 458 mm
#define DMPAPER_P16K_ROTATED        106 // PRC 16K Rotated
#define DMPAPER_P32K_ROTATED        107 // PRC 32K Rotated
#define DMPAPER_P32KBIG_ROTATED     108 // PRC 32K(Big) Rotated
#define DMPAPER_PENV_1_ROTATED      109 // PRC Envelope #1 Rotated 165 x 102 mm
#define DMPAPER_PENV_2_ROTATED      110 // PRC Envelope #2 Rotated 176 x 102 mm
#define DMPAPER_PENV_3_ROTATED      111 // PRC Envelope #3 Rotated 176 x 125 mm
#define DMPAPER_PENV_4_ROTATED      112 // PRC Envelope #4 Rotated 208 x 110 mm
#define DMPAPER_PENV_5_ROTATED      113 // PRC Envelope #5 Rotated 220 x 110 mm
#define DMPAPER_PENV_6_ROTATED      114 // PRC Envelope #6 Rotated 230 x 120 mm
#define DMPAPER_PENV_7_ROTATED      115 // PRC Envelope #7 Rotated 230 x 160 mm
#define DMPAPER_PENV_8_ROTATED      116 // PRC Envelope #8 Rotated 309 x 120 mm
#define DMPAPER_PENV_9_ROTATED      117 // PRC Envelope #9 Rotated 324 x 229 mm
#define DMPAPER_PENV_10_ROTATED     118 // PRC Envelope #10 Rotated 458 x 324 mm
// Start rmmcups: added some more values used on Unix here
#define DMPAPER_ENV_DL_ROTATED      119 // Envelope DL Rotated 22 x 110
#define DMPAPER_A4_LONG							120
#define DMPAPER_ORGANIZER_J					121
#define DMPAPER_ORGANIZER_K					122
#define DMPAPER_LAST                DMPAPER_ORGANIZER_K
// End rmmcups

#define DMPAPER_USER                256

#define DMBIN_USER									256

#define REG_SZ  1

// Dynamic Library Functions
#define DLL_PROCESS_ATTACH          1 // MHUX001
#define DLL_THREAD_ATTACH           2 // MHUX001
#define DLL_THREAD_DETACH           3 // MHUX001
#define DLL_PROCESS_DETACH          0 // MHUX001
#define SEM_FAILCRITICALERRORS      0x0001
#define SEM_NOOPENFILEERRORBOX      0x8000
UINT SetErrorMode(UINT);
HMODULE LoadLibrary(LPCSTR);
DWORD GetModuleFileName(HMODULE,LPSTR,DWORD);
HMODULE GetModuleHandle(LPCTSTR);
BOOL FreeLibrary(HMODULE);
FARPROC GetProcAddress(HMODULE,LPCSTR);

// Palettes
typedef struct tagPALETTEENTRY
{
	BYTE peRed;
	BYTE peGreen;
	BYTE peBlue;
	BYTE peFlags;
} PALETTEENTRY, *LPPALETTEENTRY;
typedef struct tagLOGPALETTE
{
    WORD        palVersion;
    WORD        palNumEntries;
    PALETTEENTRY        palPalEntry[1];
} LOGPALETTE, *LPLOGPALETTE;
#define PC_RESERVED     0x01    /* palette index used for animation */
#define WM_QUERYNEWPALETTE              0x030F
#define WM_PALETTECHANGED               0x0311
#define GetRValue(rgb)      ((BYTE)(rgb))
#define GetGValue(rgb)      ((BYTE)(((WORD)(rgb)) >> 8))
#define GetBValue(rgb)      ((BYTE)((rgb)>>16))

#define RC_BANDING          2       /* Device requires banding support  */
#define RC_PALETTE          0x0100      /* supports a palette           */

#define NUMCOLORS     24    /* Number of colors the device supports     */
UINT  SetPaletteEntries(HPALETTE, UINT, UINT, PALETTEENTRY *);
HPALETTE CreatePalette(LOGPALETTE *);
UINT RealizePalette(HDC);
HPALETTE SelectPalette(HDC, HPALETTE, BOOL);

// Menu
typedef struct tagMEASUREITEMSTRUCT {
    UINT       CtlType;
    UINT       CtlID;
    UINT       itemID;
    UINT       itemWidth;
    UINT       itemHeight;
    ULONG_PTR  itemData;	// rmm9422
} MEASUREITEMSTRUCT,*LPMEASUREITEMSTRUCT;
typedef struct tagDRAWITEMSTRUCT {
    UINT        CtlType;
    UINT        CtlID;
    UINT        itemID;
    UINT        itemAction;
    UINT        itemState;
    HWND        hwndItem;
    HDC         hDC;
    RECT        rcItem;
    ULONG_PTR   itemData; // rmm9422
} DRAWITEMSTRUCT, *LPDRAWITEMSTRUCT;
#define ODT_MENU        1
#define ODS_SELECTED    0x0001
#define ODS_GRAYED      0x0002
#define ODS_DISABLED    0x0004
#define ODS_CHECKED     0x0008

#define OBM_CHECK           32760
#define OBM_LFARROW         32750
#define OBM_RGARROW         32751
#define OBM_RGARROWI        32735
#define OBM_LFARROWD        32740
#define OBM_RGARROWD        32741
#define OBM_UPARROW         32753
#define OBM_DNARROW         32752
#define OBM_UPARROWI        32737
#define OBM_DNARROWI        32736
#define OBM_UPARROWD        32743
#define OBM_DNARROWD        32742
#define OBM_LFARROWI        32734

#define WM_INITMENU                     0x0116
#define MF_UNCHECKED        0x00000000L
#define MF_CHECKED          0x00000008L
#define MF_OWNERDRAW        0x00000100L
#define MF_ENABLED          0x00000000L
#define MF_GRAYED           0x00000001L
#define MF_DISABLED         0x00000002L
#define MF_BYCOMMAND        0x00000000L
#define MF_STRING           0x00000000L
#define MF_POPUP            0x00000010L
#define MF_BYPOSITION       0x00000400L
#define MF_SEPARATOR        0x00000800L
#define SC_SIZE							0xF000
#define SC_MOVE							0xF010
#define SC_MINIMIZE					0xF020
#define SC_MAXIMIZE					0xF030
#define SC_RESTORE					0xF120
#define SC_CLOSE						0xF060
#define SC_KEYMENU					0xF100
#define SC_TASKLIST					0xF130
#define SC_CONTEXTHELP			0xF180
#define TPM_LEFTBUTTON			0x0000L
#define TPM_RIGHTBUTTON			0x0002L
#define TPM_LEFTALIGN				0x0000L
#define TPM_CENTERALIGN			0x0004L
#define TPM_RIGHTALIGN			0x0008L
#define TPM_TOPALIGN        0x0000L
#define TPM_BOTTOMALIGN     0x0020L
#define TPM_NONOTIFY				0x0080L	// rmm_rfmenu
#define TPM_RETURNCMD				0x0100L	// rmm_rfmenu

typedef struct tagMENUITEMINFO {
	 UINT cbSize;
	 UINT fMask;
	 UINT	wID;
} MENUITEMINFO, *LPMENUITEMINFO;
#define MIIM_ID          0x00000002

BOOL SetMenuItemInfo(HMENU hMenu,UINT,BOOL,LPMENUITEMINFO);
HMENU CreateMenu();
BOOL AppendMenu(HMENU,UINT,UINT,LPCTSTR);
HMENU GetSystemMenu(HWND,BOOL);
BOOL ModifyMenu(HMENU,UINT,UINT,UINT,LPCTSTR);
BOOL DeleteMenu(HMENU,UINT,UINT);
HMENU GetSubMenu(HMENU,int);
BOOL DestroyMenu(HMENU);
int GetMenuItemCount(HMENU);
UINT TrackPopupMenu(HMENU hMenu,UINT uFlags,int x,int y,int nReserved,HWND hWnd,CONST RECT *prcRect);	// rmm_rfmenu: was BOOL (BOOL is incorrectly unsigned char on Linux, but cannot change this now)
HMENU CreatePopupMenu();
BOOL EnableMenuItem(HMENU,UINT,UINT);
BOOL InsertMenu(HMENU,UINT,UINT,UINT,LPCTSTR);
BOOL RemoveMenu(HMENU,UINT,UINT);
UINT GetMenuState(HMENU,UINT,UINT);
DWORD CheckMenuItem(HMENU,UINT,UINT);
int GetMenuString(HMENU,UINT,LPTSTR,int,UINT);
LONG GetMenuCheckMarkDimensions();
BOOL DrawMenuBar(HWND);
HMENU GetMenuClicked(HWND,UINT,UINT,UINT*,BOOL,BOOL*);
HMENU GetMenuFromVK(HWND,WPARAM,LPARAM,UINT* pXPos,BOOL);
void SetMenuBarFont(HFONT pFont);	// rmm6202

// Misc
BOOL SetMessageQueue(int);

// Define SetRect as XIsetRect to avoid function clash with PGSDK
#define SetRect XIsetRect
BOOL SetRect(LPRECT,int,int,int,int);

DWORD GetLastError();
DWORD GetVersion();
UINT RegisterWindowMessage(LPCSTR);
LRESULT SendMessage(HWND,UINT,WPARAM,LPARAM);
LRESULT PostMessage(HWND,UINT,WPARAM,LPARAM);
LRESULT RequeueMessage(LPMSG pMsg);	// rmm5974: Unix-specific API to requeue a complete MSG

#define QUEUE_EMPTY  0
#define QUEUE_XMSG   1
#define QUEUE_WMSG   2
void SendEventMessage(LPMSG);
INT xevent2Win(void* pXEvent,LPMSG pMsg,BOOL pIgnoreQueued);
INT AnyEventsQueued();

void PostQuitMessage(int);
DWORD GetCurrentProcessId();
DWORD GetSysColor(int);
int MulDiv(int,int,int);
BOOL ClientToScreen(HWND,LPPOINT);

#define FILEOKSTRING   "commdlg_FileNameOK"
#define MAKEINTRESOURCE(i) (LPSTR)((ULONG_PTR)((WORD)(i))) // rmm64bitux
// HITTEST
#define HTERROR             (-2)
#define HTTRANSPARENT       (-1)
#define HTNOWHERE           0
#define HTCLIENT            1
#define HTCAPTION           2
#define HTSYSMENU           3
#define HTGROWBOX           4
#define HTSIZE              HTGROWBOX
#define HTMENU              5
#define HTHSCROLL           6
#define HTVSCROLL           7
#define HTMINBUTTON         8
#define HTMAXBUTTON         9
#define HTLEFT              10
#define HTRIGHT             11
#define HTTOP               12
#define HTTOPLEFT           13
#define HTTOPRIGHT          14
#define HTBOTTOM            15
#define HTBOTTOMLEFT        16
#define HTBOTTOMRIGHT       17
#define HTBORDER            18
#define HTREDUCE            HTMINBUTTON
#define HTZOOM              HTMAXBUTTON
#define HTSIZEFIRST         HTLEFT
#define HTSIZELAST          HTBOTTOMRIGHT
#define HTCLOSE             20
#define	HTHELP							21

ATOM GlobalDeleteAtom(ATOM);
UINT GlobalGetAtomName(ATOM,LPSTR,int);
HBRUSH CreateSolidBrush(COLORREF);

// Icon
#define IMAGE_ICON          1
#define ICON_SMALL          0
#define ICON_BIG            1
typedef struct tagICONINFO {
    BOOL    fIcon;
    DWORD   xHotspot;
    DWORD   yHotspot;
    HBITMAP hbmMask;
    HBITMAP hbmColor;
} ICONINFO;
HICON LoadIcon(HINSTANCE,LPCTSTR);
BOOL DestroyIcon(HICON);
HANDLE LoadImage(HINSTANCE,LPCTSTR,UINT,int,int,UINT);

typedef struct tagCREATESTRUCT
{
  LPVOID lpCreateParams;
  HINSTANCE hInstance;
  HMENU hMenu;
  HWND hwndParent;
  int cy;
  int cx;
  int y;
  int x;
  LONG style;
  LPCSTR lpszName;
  LPCSTR lpszClass;
  DWORD dwExStyle;
} CREATESTRUCT,*LPCREATESTRUCT;

#define COLOR_SCROLLBAR         0
#define COLOR_BACKGROUND        1
#define COLOR_ACTIVECAPTION     2
#define COLOR_INACTIVECAPTION   3
#define COLOR_MENU              4
#define COLOR_WINDOW            5
#define COLOR_WINDOWFRAME       6
#define COLOR_MENUTEXT          7
#define COLOR_WINDOWTEXT        8
#define COLOR_CAPTIONTEXT       9
#define COLOR_ACTIVEBORDER      10
#define COLOR_INACTIVEBORDER    11
#define COLOR_APPWORKSPACE      12
#define COLOR_HIGHLIGHT         13
#define COLOR_HIGHLIGHTTEXT     14
#define COLOR_BTNFACE           15
#define COLOR_BTNSHADOW         16
#define COLOR_GRAYTEXT          17
#define COLOR_BTNTEXT           18
#define COLOR_INACTIVECAPTIONTEXT 19
#define COLOR_BTNHIGHLIGHT      20
#define COLOR_3DDKSHADOW        21
#define COLOR_3DLIGHT           22
#define COLOR_INFOTEXT          23
#define COLOR_INFOBK            24
#define COLOR_OMNIS_PLAINBORDER	25	// rmmcups
#define COLOR_HOTLIGHT          26	// rmmcups

#define COLOR_DESKTOP           COLOR_BACKGROUND
#define COLOR_3DFACE            51	// rmmcups
#define COLOR_3DSHADOW          COLOR_BTNSHADOW
#define COLOR_3DHIGHLIGHT       COLOR_BTNHIGHLIGHT
#define COLOR_3DHILIGHT         COLOR_BTNHIGHLIGHT
#define COLOR_BTNHILIGHT        COLOR_BTNHIGHLIGHT

typedef struct tagBUTTONCOLORS	// rmmcups
{
	COLORREF color1,color2,color3,mFaceColorDown,color5,mFaceColor;
} BUTTONCOLORS;

void GetSystemButtonColors(BUTTONCOLORS *pColors);	// rmmcups

typedef struct tagMINMAXINFO {
    POINT ptReserved;
    POINT ptMaxSize;
    POINT ptMaxPosition;
    POINT ptMinTrackSize;
    POINT ptMaxTrackSize;
} MINMAXINFO, *PMINMAXINFO, *LPMINMAXINFO;

// Keyboard
SHORT GetKeyState(int);
UINT RegisterClipboardFormat(LPCSTR);
void GrabKeyboard(HWND pHwnd);		// rmm3667
void UngrabKeyboard();						// rmm3667

// INI
void GetOmnisXiFolder(char* pPath);
void SetOmnisXiFolder(LPCSTR pFolderPath);
DWORD GetProfileString(LPCSTR lpAppName,LPCSTR lpKeyName,LPCSTR lpDefault,LPSTR lpReturnedString,DWORD nSize);
BOOL WriteProfileString(LPCSTR lpAppName, LPCSTR lpKeyName,LPCSTR lpString);
DWORD GetPrivateProfileString(LPCSTR lpAppName,LPCSTR lpKeyName,LPCSTR lpDefault,LPSTR lpReturnedString,DWORD nSize,LPCSTR);
BOOL WritePrivateProfileString(LPCSTR lpAppName, LPCSTR lpKeyName,LPCSTR lpString,LPCSTR);
DWORD GetProfileSection(LPCSTR lpAppName,LPSTR lpReturnedString,DWORD nSize);
DWORD GetPrivateProfileSection(LPCSTR pAppName,LPSTR lpReturnedString,DWORD nSize,LPCSTR pFile);
LPSTR GetWinString(INT pId);			// rmm64bitux
LPSTR GetWinStringUtf8(INT pId);	// rmmcups // rmm64bitux
void SetWinString(INT pId,char*);	// rmm64bitux

#define WINSTR_YES 											0
#define	WINSTR_NO 											1
#define WINSTR_OK 											2
#define WINSTR_CANCEL 									3
#define WINSTR_ABORT 										4
#define WINSTR_RETRY 										5
#define WINSTR_IGNORE 									6
#define WINSTR_OPEN 										7
#define WINSTR_SAVEAS 									8
#define WINSTR_FILE 										9
#define WINSTR_FILES 										10
#define WINSTR_LISTFILES 								11
#define WINSTR_DIRECTORIES 							12
#define WINSTR_ALLFILTER 								13
#define WINSTR_CREATEPROMPT 						14
#define WINSTR_FILEMUSTEXIST 						15
#define WINSTR_OVERWRITEPROMPT 					16
#define WINSTR_PATHMUSTEXIST 						17
#define WINSTR_BADCOLORDEPTH 						18
#define WINSTR_INITFONTCACHE 						19
#define WINSTR_INITXFT 									20
// Start rmmcups
#define WINSTR_DEFAULTBIN 							21
#define WINSTR_A4 											22
#define WINSTR_LETTER 									23
#define WINSTR_TABLOID 									24
#define WINSTR_LEDGER 									25
#define WINSTR_LEGAL 										26
#define WINSTR_STATEMENT 								27
#define WINSTR_EXECUTIVE 								28
#define WINSTR_A3 											29
#define WINSTR_A5 											30
#define WINSTR_B4 											31
#define WINSTR_B5 											32
#define WINSTR_FOLIO 										33
#define WINSTR_QUARTO 									34
#define WINSTR_10X14 										35
#define WINSTR_11X17 										36
#define WINSTR_NOTE 										37
#define WINSTR_ENV_9 										38
#define WINSTR_ENV_10 									39
#define WINSTR_ENV_11 									40
#define WINSTR_ENV_12 									41
#define WINSTR_ENV_14 									42
#define WINSTR_CSHEET 									43
#define WINSTR_DSHEET 									44
#define WINSTR_ESHEET 									45
#define WINSTR_ENV_DL 									46
#define WINSTR_ENV_C5 									47
#define WINSTR_ENV_C3 									48
#define WINSTR_ENV_C4 									49
#define WINSTR_ENV_C6 									50
#define WINSTR_ENV_C65 									51
#define WINSTR_ENV_B4 									52
#define WINSTR_ENV_B5 									53
#define WINSTR_ENV_B6 									54
#define WINSTR_ENV_ITALY 								55
#define WINSTR_ENV_MONARCH 							56
#define WINSTR_ENV_PERSONAL 						57
#define WINSTR_FANFOLD_US 							58
#define WINSTR_FANFOLD_STD_GERMAN 			59
#define WINSTR_FANFOLD_LGL_GERMAN 			60
#define WINSTR_ISO_B4 									61
#define WINSTR_JAPANESE_POSTCARD				62
#define WINSTR_9X11 										63
#define WINSTR_10X11 										64
#define WINSTR_15X11 										65
#define WINSTR_ENV_INVITE 							66
#define WINSTR_LETTER_EXTRA 						67
#define WINSTR_LEGAL_EXTRA							68
#define WINSTR_TABLOID_EXTRA						69
#define WINSTR_A4_EXTRA 								70
#define WINSTR_LETTER_TRANSVERSE				71
#define WINSTR_A4_TRANSVERSE						72
#define WINSTR_LETTER_EXTRA_TRANSVERSE	73
#define WINSTR_A_PLUS										74
#define WINSTR_B_PLUS										75
#define WINSTR_LETTER_PLUS							76
#define WINSTR_A4_PLUS									77
#define WINSTR_A5_TRANSVERSE						78
#define WINSTR_B5_TRANSVERSE						79
#define WINSTR_A3_EXTRA									80
#define WINSTR_A5_EXTRA 								81
#define WINSTR_B5_EXTRA									82
#define WINSTR_A2 											83
#define WINSTR_A3_TRANSVERSE 						84
#define WINSTR_A3_EXTRA_TRANSVERSE			85
#define	WINSTR_UNKNOWN									86
#define WINSTR_A6												87
#define WINSTR_ENV_DL_ROTATED						88
#define WINSTR_A4_LONG									89
#define WINSTR_ORGANIZER_J							90
#define WINSTR_ORGANIZER_K							91
#define WINSTR_SAVE											92
#define WINSTR_ALREADYEXISTS						93
#define WINSTR_LOCKEDORINUSE						94
#define WINSTR_ERROR										95
#define WINSTR_OPENFILE									96
#define WINSTR_SAVEFILE									97
#define WINSTR_SELECTDIRECTORY					98
#define WINSTR_PRINT_SETUP_TITLE				99	// Print dialog strings start here
#define WINSTR_PR_NAME									100
#define WINSTR_PR_TYPE									101
#define WINSTR_PR_SIZE									102
#define WINSTR_PR_TRAY									103
#define WINSTR_PR_PORTRAIT							104
#define WINSTR_PR_LANDSCAPE							105
#define WINSTR_PR_PROPERTIES						106
#define WINSTR_PR_PRINTER								107
#define WINSTR_PR_PAPER									108
#define WINSTR_PR_ORIENTATION						109
#define WINSTR_PROPERTIES_TITLE					110
#define WINSTR_PR_DEVICE								111
#define WINSTR_PR_DUPLEX								112
#define WINSTR_PR_SCALE									113
#define WINSTR_PR_OPTION								114
#define WINSTR_PR_VALUE									115
#define WINSTR_PR_COPIES								116
#define WINSTR_PR_NUMBER_OF_COPIES			117
#define WINSTR_PR_ALL										118
#define WINSTR_PR_PAGES									119
#define WINSTR_PR_PAGES_HELP						120
#define WINSTR_JOB_SETUP_TITLE					121
#define WINSTR_PR_NONE									122
#define WINSTR_DUPLEX_SHORT_EDGE				123
#define WINSTR_DUPLEX_LONG_EDGE					124	
#define WINSTR_CLASSIFIED								125
#define WINSTR_CONFIDENTIAL							126
#define WINSTR_SECRET										127
#define WINSTR_STANDARD									128
#define WINSTR_TOP_SECRET								129
#define WINSTR_UNCLASSIFIED							130
#define WINSTR_PR_BEFORE								131
#define WINSTR_PR_AFTER									132
#define WINSTR_PR_BANNERS								133	
#define WINSTR_PR_RESTOREDEFAULTS				134	// Print dialog strings end here
// End rmmcups

// Bitblt
#define SRCCOPY             (DWORD)0x00CC0020 /* dest = source                   */
#define SRCAND              (DWORD)0x008800C6 /* dest = source AND dest          */
#define SRCINVERT           (DWORD)0x00660046 /* dest = source XOR dest          */
#define SRCPAINT            (DWORD)0x00EE0086 /* dest = source OR dest           */
#define DSTINVERT           (DWORD)0x00550009 /* dest = (NOT dest)               */
#define NOTSRCCOPY          (DWORD)0x00330008 /* dest = (NOT source)             */
#define PATCOPY             (DWORD)0x00F00021 /* dest = pattern                  */
#define WHITENESS           (DWORD)0x00FF0062 /* dest = WHITE                    */
#define BLACKNESS           (DWORD)0x00000042
#define PATINVERT           (DWORD)0x005A0049 

#define CS_DBLCLKS          0x0008
#define CS_SAVEBITS         0x0800

// Redraw flags
#define RDW_INTERNALPAINT   0x0002
#define RDW_ERASE               0x0004
#define RDW_INVALIDATE          0x0001
#define RDW_ALLCHILDREN         0x0080
#define RDW_FRAME               0x0400
#define RDW_UPDATENOW           0x0100
#define RDW_VALIDATE            0x0008
#define RDW_ERASENOW   0x0200
#define RDW_NOCHILDREN  0x0040

#define DLGWINDOWEXTRA 30

// Class
typedef struct tagWNDCLASS {
    UINT        style;
    WNDPROC     lpfnWndProc;
    int         cbClsExtra;
    int         cbWndExtra;
    HINSTANCE   hInstance;
    HICON       hIcon;
    HCURSOR     hCursor;
    HBRUSH      hbrBackground;
    LPCSTR      lpszMenuName;
    LPCSTR      lpszClassName;
} WNDCLASS,*LPWNDCLASS;
typedef struct tagWNDCLASSEX {
    UINT        cbSize;
    /* Win 3.x */
    UINT        style;
    WNDPROC     lpfnWndProc;
    int         cbClsExtra;
    int         cbWndExtra;
    HINSTANCE   hInstance;
    HICON       hIcon;
    HCURSOR     hCursor;
    HBRUSH      hbrBackground;
    LPCSTR      lpszMenuName;
    LPCSTR      lpszClassName;
    /* Win 4.0 */
    HICON       hIconSm;
  int mFrameBorderWidth;
  int mClientBorderWidth;
} WNDCLASSEX,*LPWNDCLASSEX;
BOOL RegisterClassEx(const WNDCLASSEX*);
BOOL RegisterClass(const WNDCLASS*);
BOOL UnregisterClass(LPCTSTR pClass,HINSTANCE pInst);

BOOL ScreenToClient(HWND,LPPOINT);

/* Mapping Modes */
#define MM_TEXT             1
#define MM_HIMETRIC         3
#define MM_ANISOTROPIC      8
int SetMapMode(HDC,int);

BOOL DrawIcon(HDC,int x,int y,HICON);
HBITMAP CreateBitmap(int,int,UINT,UINT,void*);
HBITMAP CreateCompatibleBitmap(HDC,int,int);
HDC CreateCompatibleDC(HDC);
HBITMAP LoadBitmap(HINSTANCE,LPCTSTR);
BOOL BitBlt(HDC,int,int,int,int,HDC,int,int,DWORD);
BOOL BitBltMask(HDC pDestHdc,int pDL,int pDT,int pDW,int pDH,HDC pSrcDc,int pSL,int pST,HBITMAP pMask);
BOOL BitBltHilite(HDC pHdc,int pDL,int pDT,int pSL,int pST,int pDW,int pDH,HBITMAP pBitMapMask); // V1.3
LONG SetBitmapBits(HBITMAP, DWORD, CONST VOID *);

// Message
#define PM_NOREMOVE         0x0000
#define PM_REMOVE           0x0001
#define PM_NOYIELD          0x0002
LRESULT DispatchMessage(const MSG*); // rmmheadless: LRESULT
BOOL PeekMessage(LPMSG,HWND,UINT,UINT,UINT);
BOOL GetMessage(LPMSG lpMsg,HWND hWnd ,UINT wMsgFilterMin,UINT wMsgFilterMax);
BOOL TranslateMessage(const MSG*);
HWND FlushPaints();
void *GetXDisplay();

HGDIOBJ SelectObject(HDC,HGDIOBJ);
#define OBJ_FONT 6																		// rmm5993: only option currently supported by GetCurrentObject
HGDIOBJ GetCurrentObject(HDC hdc, UINT uObjectType);	// rmm5993
HGDIOBJ GetStockObject(int);

typedef struct tagWINDOWPLACEMENT {
    UINT  length;
    UINT  flags;
    UINT  showCmd;
    POINT ptMinPosition;
    POINT ptMaxPosition;
    RECT  rcNormalPosition;
} WINDOWPLACEMENT;
BOOL GetWindowPlacement(HWND,WINDOWPLACEMENT*);
BOOL SetWindowPlacement(HWND,WINDOWPLACEMENT*);
HWND GetForegroundWindow();
     
// Dialog styles
#define IDOK            1
#define IDCANCEL        2
#define IDABORT         3
#define IDRETRY         4
#define IDIGNORE        5
#define IDYES           6
#define IDNO            7
#define DS_SETFONT          0x40L   /* User specified font for Dlg controls */
BOOL MapDialogRect(HWND,LPRECT);
BOOL EndDialog(HWND,int);
void SetModalDialog(BOOL pModalDialog);		// rmmcups
BOOL DiscardMessageWhenModal(MSG *pMsg);	// rmmcups
void CheckWindowDecorations();						// rmmcups
void SetDockingArea(HWND pHwnd);					// rmmcups
void AdjustToolbarPopupRect(HWND pHwnd, RECT *pRect);						// rmmcups
void AdjustWindowPositionForConfig(HWND pHwnd, RECT *pRect);		// rmmcups
BOOL IsKDE();															// rmmcups

// Resource functions
#define RT_CURSOR           MAKEINTRESOURCE(1)
#define RT_BITMAP           MAKEINTRESOURCE(2)
#define RT_ICON             MAKEINTRESOURCE(3)
#define RT_MENU             MAKEINTRESOURCE(4)
#define RT_DIALOG           MAKEINTRESOURCE(5)
#define RT_STRING           MAKEINTRESOURCE(6)
#define RT_FONTDIR          MAKEINTRESOURCE(7)
#define RT_FONT             MAKEINTRESOURCE(8)
#define RT_ACCELERATOR      MAKEINTRESOURCE(9)
#define RT_RCDATA           MAKEINTRESOURCE(10)
#define RT_MESSAGETABLE     MAKEINTRESOURCE(11)

// Standard icons
#define IDI_HAND    MAKEINTRESOURCE(32513)
#define IDI_QUESTION   MAKEINTRESOURCE(32514)
#define IDI_EXCLAMATION  MAKEINTRESOURCE(32515)
#define IDI_ASTERISK    MAKEINTRESOURCE(32516)

HGLOBAL LoadResource(HMODULE,HRSRC);
HRSRC FindResource(HMODULE,LPCTSTR,LPCTSTR);
LPVOID LockResource(HGLOBAL);
int UnlockResource(HGLOBAL);
BOOL FreeResource(HGLOBAL);
int LoadString(HINSTANCE,UINT,LPSTR,int);

// MHUNILX begins
// Character Types
#define DEFAULT_CHARSET         1
#define BALTIC_CHARSET          186
#define CHINESEBIG5_CHARSET     136
#define EASTEUROPE_CHARSET      238
#define GB2312_CHARSET          134
#define GREEK_CHARSET           161
#define HANGUL_CHARSET          129
#define MAC_CHARSET             77
#define RUSSIAN_CHARSET         204
#define SHIFTJIS_CHARSET        128
#define TURKISH_CHARSET         162
#define VIETNAMESE_CHARSET      163	// rmmunilnx3
#define JOHAB_CHARSET           130
#define HEBREW_CHARSET          177
#define ARABIC_CHARSET          178
#define THAI_CHARSET            222
// MHUNILX ends

// Font
#define TMPF_TRUETYPE       0x04
#define TMPF_FIXED_PITCH    0x01
#define TMPF_VECTOR         0x02
#define TMPF_DEVICE         0x08
#define TMPF_TRUETYPE       0x04

#define OUT_TT_ONLY_PRECIS  7

#define FF_DONTCARE         (0<<4)  /* Don't care or don't know. */
#define FF_ROMAN   (1<<4)
#define FF_SWISS  (2<<4)
#define FF_MODERN (3<<4)
#define FF_SCRIPT (4<<4)
#define FF_DECORATIVE  (5<<4)

/* Font Weights */
#define FW_DONTCARE         0
#define FW_THIN             100
#define FW_EXTRALIGHT       200
#define FW_LIGHT            300
#define FW_NORMAL           400
#define FW_MEDIUM           500
#define FW_SEMIBOLD         600
#define FW_BOLD             700
#define FW_EXTRABOLD        800
#define FW_HEAVY            900

#define FW_ULTRALIGHT       FW_EXTRALIGHT
#define FW_REGULAR          FW_NORMAL
#define FW_DEMIBOLD         FW_SEMIBOLD
#define FW_ULTRABOLD        FW_EXTRABOLD
#define FW_BLACK            FW_HEAVY

#define ANSI_CHARSET        0
#define OEM_CHARSET 255
#define SYMBOL_CHARSET 2

#define OUT_DEFAULT_PRECIS  0
#define CLIP_DEFAULT_PRECIS 0
#define DEFAULT_QUALITY         0
#define DEFAULT_PITCH           0
#define FIXED_PITCH             1
#define VARIABLE_PITCH          2
#define DRAFT_QUALITY           1
#define FF_MODERN           (3<<4)  /* Constant stroke width, serifed or sans-serifed. */
#define DEVICE_FONTTYPE         0x002  
#define RASTER_FONTTYPE         0x0001 
#define TRUETYPE_FONTTYPE       0x004  
typedef struct tagTEXTMETRIC
{
    LONG        tmHeight;
    LONG        tmAscent;
    LONG        tmDescent;
    LONG        tmInternalLeading;
    LONG        tmExternalLeading;
    LONG        tmAveCharWidth;
    LONG        tmMaxCharWidth;
    LONG        tmWeight;
    LONG        tmOverhang;
    LONG        tmDigitizedAspectX;
    LONG        tmDigitizedAspectY;
    BYTE        tmFirstChar;
    BYTE        tmLastChar;
    BYTE        tmDefaultChar;
    BYTE        tmBreakChar;
    BYTE        tmItalic;
    BYTE        tmUnderlined;
    BYTE        tmStruckOut;
    BYTE        tmPitchAndFamily;
    BYTE        tmCharSet;
} TEXTMETRIC, *LPTEXTMETRIC;
//void GetObject( HFONT, int, LOGFONT*);


typedef struct tagNONCLIENTMETRICS
{
    UINT    cbSize;
    int     iBorderWidth;
    int     iScrollWidth;
    int     iScrollHeight;
    int     iCaptionWidth;
    int     iCaptionHeight;
    LOGFONT lfCaptionFont;
    int     iSmCaptionWidth;
    int     iSmCaptionHeight;
    LOGFONT lfSmCaptionFont;
    int     iMenuWidth;
    int     iMenuHeight;
    LOGFONT lfMenuFont;
    LOGFONT lfStatusFont;
    LOGFONT lfMessageFont;
}   NONCLIENTMETRICS, *LPNONCLIENTMETRICS;

// System parameter ifo
#define SPI_GETNONCLIENTMETRICS    41
BOOL SystemParametersInfo(UINT,UINT,PVOID,UINT);
HFONT   CreateFontIndirect(CONST LOGFONT *);
// MHUX001 begins.
HFONT   CreateFont(int, int, int, int, int, DWORD,
                   DWORD, DWORD, DWORD, DWORD, DWORD,
                   DWORD, DWORD, LPCSTR);
void GetFontInfo(HFONT, LPFONTINFO);	// rmmunilnx2
// MHUX001 ends.
typedef struct tagLOGBRUSH
{
  int lbStyle;
} LOGBRUSH, *LPBRUSH;
//int GetObject(HBRUSH,int,LPBRUSH);
typedef struct tagLOGPEN
  {
    UINT        lopnStyle;
    POINT       lopnWidth;
    COLORREF    lopnColor;
  } LOGPEN, *LPLOGPEN;
//HPEN GetObject(HPEN,int,LOGPEN*);


// WinHelp
#define HELP_CONTEXT      0x0001L  /* Display topic in ulTopic */
#define HELP_QUIT         0x0002L  /* Terminate help */
#define HELP_CONTENTS     0x0003L
#define HELP_CONTEXTPOPUP 0x0008L
BOOL WinHelp(HWND hWndMain,LPCSTR lpszHelp,UINT uCommand,DWORD dwData);

// Cursors
// Start rmmunilnx3
#define IDC_ARROW_INT       32512
#define IDC_SIZENS_INT      32645
#define IDC_SIZEWE_INT      32644
#define IDC_SIZENWSE_INT    32642
#define IDC_SIZENESW_INT    32643
#define IDC_IBEAM_INT       32513
#define IDC_WAIT_INT        32514
#define IDC_CROSS_INT       32515
#define IDC_SIZEALL_INT     32646
#define IDC_APPSTARTING_INT 32650
#define IDC_HELP_INT        32651

#define IDC_ARROW           MAKEINTRESOURCE(IDC_ARROW_INT)
#define IDC_SIZENS          MAKEINTRESOURCE(IDC_SIZENS_INT)
#define IDC_SIZEWE          MAKEINTRESOURCE(IDC_SIZEWE_INT)
#define IDC_SIZENWSE        MAKEINTRESOURCE(IDC_SIZENWSE_INT)
#define IDC_SIZENESW        MAKEINTRESOURCE(IDC_SIZENESW_INT)
#define IDC_IBEAM						MAKEINTRESOURCE(IDC_IBEAM_INT)
#define IDC_WAIT            MAKEINTRESOURCE(IDC_WAIT_INT)
#define IDC_CROSS           MAKEINTRESOURCE(IDC_CROSS_INT)
#define IDC_SIZEALL         MAKEINTRESOURCE(IDC_SIZEALL_INT)
#define IDC_APPSTARTING     MAKEINTRESOURCE(IDC_APPSTARTING_INT)
#define IDC_HELP            MAKEINTRESOURCE(IDC_HELP_INT)
// End rmmunilnx3

#define NULL_BRUSH          5
#define NULL_PEN            8
#define DEFAULT_PALETTE     15

/* Pen Styles */
#define PS_SOLID            0
#define PS_DASH             1       /* -------  */
#define PS_DOT              2       /* .......  */
#define PS_DASHDOT          3       /* _._._._  */
#define PS_DASHDOTDOT       4       /* _.._.._  */
#define PS_NULL             5
#define PS_INSIDEFRAME      6
#define PS_USERSTYLE        7
#define PS_ALTERNATE        8
#define PS_STYLE_MASK       0x0000000F

#define  FLOODFILLSURFACE  1

#define DT_VCENTER          0x00000004
#define DT_RASDISPLAY       1   /* Raster display                   */
#define DT_SINGLELINE 0x00000020
#define DT_NOCLIP   0x00000100
#define DT_NOPREFIX  0x00000800
#define DT_WORDBREAK 0x00000010
#define DT_EXPANDTABS 0x00000040
#define DT_TABSTOP 0x00000080
#define DT_EXTERNALLEADING  0x00000200
#define DT_CALCRECT  0x00000400
#define DT_CENTER  0x00000001
#define DT_RIGHT   0x00000002
#define DT_BOTTOM  0x00000008
#define DT_LEFT    0x00000000
#define DT_TOP     0x00000000

#define MM_ISOTROPIC        7
#define MM_TWIPS            6

#define MA_ACTIVATE         1

// CreateDIB
#define CBM_INIT        0x04L   /* initialize bitmap */
#define DIB_RGB_COLORS      0 /* color table in RGBs */

// Scroll
#define SW_SCROLLCHILDREN   0x0001  /* Scroll children within *lprcScroll. */
#define SW_INVALIDATE       0x0002  /* Invalidate after scrolling */
#define SW_ERASE            0x0004  /* If SW_INVALIDATE, don't send WM_ERASEBACKGROUND */
#define SIF_RANGE           0x0001  /* MHSCROLL */
#define SIF_PAGE            0x0002  /* MHSCROLL */
#define SIF_POS             0x0004  /* MHSCROLL */
#define SIF_DISABLENOSCROLL 0x0008  /* MHSCROLL */
#define SIF_TRACKPOS        0x0010  /* MHSCROLL */
#define SIF_ALL             (SIF_RANGE | SIF_PAGE | SIF_POS | SIF_TRACKPOS) /* MHSCROLL */

typedef struct tagSCROLLINFO
{
    UINT    cbSize;
    UINT    fMask;
    int     nMin;
    int     nMax;
    UINT    nPage;
    int     nPos;
    int     nTrackPos;
}   SCROLLINFO, *LPSCROLLINFO;

/*
 * Key State Masks for Mouse Messages
 */
#define MK_LBUTTON          0x0001
#define MK_RBUTTON          0x0002
#define MK_SHIFT            0x0004
#define MK_CONTROL          0x0008
#define MK_MBUTTON          0x0010
#define KEYEVENTF_KEYUP       0x0002

// CALLWNDPROC
typedef struct tagCWPSTRUCT {
    LPARAM  lParam;
    WPARAM  wParam;
    UINT    message;
    HWND    hwnd;
} CWPSTRUCT, *PCWPSTRUCT, *NPCWPSTRUCT, *LPCWPSTRUCT;

// SetWindowsHook
#define WH_CALLWNDPROC      4
#define WH_MSGFILTER        (-1)

/*
 * WH_MSGFILTER Filter Proc Codes
 */
#define MSGF_DIALOGBOX      0
#define MSGF_MESSAGEBOX     1
#define MSGF_MENU           2
#define MSGF_MOVE           3
#define MSGF_SIZE           4
#define MSGF_SCROLLBAR      5
#define MSGF_NEXTWINDOW     6
#define MSGF_MAINLOOP       8
#define MSGF_MAX            8
#define MSGF_USER           4096

// Metafile
typedef struct tagMETAHEADER
{
    WORD        mtType;
    WORD        mtHeaderSize;
    WORD        mtVersion;
    DWORD       mtSize;
    WORD        mtNoObjects;
    DWORD       mtMaxRecord;
    WORD        mtNoParameters;
} METAHEADER;

HDC BeginPaint( HWND, PAINTSTRUCT* );
BOOL EndPaint(HWND,PAINTSTRUCT*);

// ANSI
LPSTR AnsiUpper(LPSTR lpsz);
DWORD AnsiUpperBuff(LPSTR lpsz,DWORD cchLength);
DWORD AnsiLowerBuff(LPSTR lpsz,DWORD cchLength);
BOOL OemToAnsi(LPCSTR lpszSrc,LPSTR lpszDst);
BOOL OemToAnsiBuff(LPCSTR lpszSrc,LPSTR lpszDst,DWORD cchDstLength);
BOOL AnsiToOem(LPCSTR lpszSrc,LPSTR lpszDst);
BOOL AnsiToOemBuff(LPCSTR lpszSrc,LPSTR lpszDst,DWORD cchDstLength);
BOOL IsCharAlpha(CHAR ch);

BOOL SetForegroundWindow(HWND);
int   WINAPI SetStretchBltMode(HDC, int);

HINSTANCE ShellExecute(HWND hwnd, LPCSTR lpOperation, LPCSTR lpFile, LPCSTR lpParameters, LPCSTR lpDirectory, INT nShowCmd);

#define WINEXEC_NOWAIT   0x00000000
#define WINEXEC_WAIT     0x00000001
#define WINEXEC_CAP_STDOUT  0x00000002
UINT WinExec(LPCSTR lpCmdLine, UINT uCmdShow); // MHEXEC
UINT WinExecEx(LPCSTR lpCmdLine, UINT uCmdShow,DWORD pFlags,HANDLE* pOutput);

BOOL testForProgOpen_Unix(LPSTR pProg); // MHEXEC

HENHMETAFILE  WINAPI SetWinMetaFileBits(UINT, CONST BYTE *, HDC, CONST METAFILEPICT *);
HMETAFILE   WINAPI SetMetaFileBitsEx(UINT, CONST BYTE *);
HENHMETAFILE  WINAPI SetEnhMetaFileBits(UINT, CONST BYTE *);
BOOL WINAPI DeleteMetaFile(HMETAFILE);
UINT  WINAPI GetEnhMetaFileHeader(HENHMETAFILE, UINT, LPENHMETAHEADER );
UINT  WINAPI GetEnhMetaFileBits(HENHMETAFILE, UINT, LPBYTE);
UINT  WINAPI GetMetaFileBitsEx(HMETAFILE, UINT, LPVOID);
LONG GetDialogBaseUnits(); // rmm64bitux
HFILE _lclose(HFILE);
HFILE _lopen(LPCSTR lpPathName,int iReadWrite);
UINT _lread(HFILE hFile,LPVOID lpBuffer,UINT uBytes);
LONG _llseek(HFILE hFile,LONG lOffset,int iOrigin);
BOOL FindNextFile(HANDLE hFindFile,LPWIN32_FIND_DATA lpFindFileData);
BOOL FileTimeToLocalFileTime(CONST FILETIME *lpFileTime,LPFILETIME lpLocalFileTime);
BOOL FileTimeToSystemTime(CONST FILETIME *lpFileTime,LPSYSTEMTIME lpSystemTime);
BOOL FileTimeToLocalSystemTime(CONST FILETIME *lpFileTime,LPSYSTEMTIME lpSystemTime); // MHn0109
DWORD GetFullPathName(LPCSTR lpFileName,DWORD nBufferLength,LPSTR lpBuffer,LPSTR *lpFilePart);
DWORD GetEnvironmentVariable(LPCSTR lpName,LPSTR lpBuffer,DWORD nSize);
BOOL CloseHandle(HANDLE);
DWORD SetFilePointer(HANDLE hFile,LONG lDistanceToMove,PLONG lpDistanceToMoveHigh,DWORD dwMoveMethod);
BOOL SetFilePointerEx(HANDLE hFile, LARGE_INTEGER liDistanceToMove, PLARGE_INTEGER lpNewFilePointer, DWORD dwMoveMethod); // rmm9010

BOOL GetCommProperties(HANDLE hFile,LPCOMMPROP lpCommProp);
DWORD GetFileSize(HANDLE hFile,LPDWORD lpFileSizeHigh);
BOOL GetFileSizeEx(HANDLE hFile, PLARGE_INTEGER lpFileSize); // rmm9010
BOOL SetEndOfFile(HANDLE);
BOOL FlushFileBuffers(HANDLE);
BOOL PurgeComm(HANDLE hFile,DWORD dwFlags);
BOOL LockFile(HANDLE hFile,DWORD dwFileOffsetLow,DWORD dwFileOffsetHigh,DWORD nNumberOfBytesToLockLow,DWORD nNumberOfBytesToLockHigh);
BOOL UnlockFile(HANDLE hFile,DWORD dwFileOffsetLow,DWORD dwFileOffsetHigh,DWORD nNumberOfBytesToUnlockLow,DWORD nNumberOfBytesToUnlockHigh);
BOOL DeleteFile(LPCSTR lpFileName);
DWORD GetTempPath(DWORD nBufferLength,LPSTR lpBuffer);
UINT GetTempFileName(LPCSTR lpPathName,LPCSTR lpPrefixString,UINT uUnique,LPSTR lpTempFileName);
BOOL GetCommState(HANDLE hFile,LPDCB lpdcb); // MHCOMM
BOOL SetCommState(HANDLE hFile,LPDCB lpdcb); // MHCOMM
BOOL BuildCommDCB(LPCSTR lpDef,LPDCB lpdcb); // MHCOMM
BOOL GetCommTimeouts(HANDLE hFile,LPCOMMTIMEOUTS lpCommTimeouts); // MHPORT
BOOL SetCommTimeouts(HANDLE hFile,LPCOMMTIMEOUTS lpCommTimeouts);
BOOL WINAPI PatBlt(HDC, int, int, int, int, DWORD);
BOOL GetKeyboardState(PBYTE lpKeyState);
BOOL SetKeyboardState(LPBYTE lpKeyState);
int  WINAPI EnumFonts(HDC, LPCSTR,  FONTENUMPROC, LPARAM);
BOOL WINAPI GetTextMetrics(HDC, LPTEXTMETRIC);
HBITMAP WINAPI CreateBitmapIndirect(CONST BITMAP *);
int   WINAPI SetROP2(HDC, int);
BOOL  WINAPI DPtoLP(HDC, LPPOINT, int);
BOOL  WINAPI LPtoDP(HDC, LPPOINT, int);
HRGN    WINAPI CreateRectRgnIndirect(CONST RECT *);
int  WINAPI ExcludeClipRect(HDC, int, int, int, int);
int  WINAPI IntersectClipRect(HDC, int, int, int, int);
void WINAPI SetPixel(HDC, int, int, COLORREF); // Void return as returning old pixel hampers performance
BOOL  WINAPI GetCurrentPositionEx(HDC, LPPOINT);
BOOL WINAPI LineDDA(int, int, int, int, LINEDDAPROC, LPARAM);
BOOL WINAPI Rectangle(HDC, int, int, int, int);
BOOL  WINAPI RoundRect(HDC, int, int, int, int, int, int);
int   WINAPI GetMapMode(HDC);
BOOL InvertRect(HDC hDC,CONST RECT *lprc);
BOOL WINAPI Ellipse(HDC, int, int, int, int);
HRGN    WINAPI CreateEllipticRgn(int, int, int, int);
BOOL   WINAPI FrameRgn(HDC, HRGN, HBRUSH, int, int);
BOOL   WINAPI FillRgn(HDC, HRGN, HBRUSH);
COLORREF WINAPI GetPixel(HDC, int, int);
BOOL  WINAPI ExtFloodFill(HDC, int, int, COLORREF, UINT);
HPEN    WINAPI CreatePen(int, int, COLORREF);
HBRUSH  WINAPI CreatePatternBrush(HBITMAP);
BOOL  WINAPI Polygon(HDC, CONST POINT *, int);
BOOL WINAPI MaskBlt(HDC, int, int, int, int,HDC, int, int, HBITMAP, int, int, DWORD);
BOOL   WINAPI StretchBlt(HDC, int, int, int, int, HDC, int, int, int, int, DWORD);
HICON CreateIconIndirect(ICONINFO* piconinfo);
int   WINAPI StretchDIBits(HDC, int, int, int, int, int, int, int, int, CONST VOID *, CONST BITMAPINFO *, UINT, DWORD);
BOOL  WINAPI GetWindowExtEx(HDC, LPSIZE);
int  WINAPI SaveDC(HDC);
BOOL  WINAPI SetViewportExtEx(HDC, int, int, LPSIZE);
BOOL  WINAPI GetViewportExtEx(HDC, LPSIZE);
BOOL  WINAPI PlayEnhMetaFile(HDC, HENHMETAFILE, CONST RECT *);
BOOL WINAPI PlayMetaFile(HDC, HMETAFILE);
BOOL WINAPI RestoreDC(HDC, int);
HBITMAP WINAPI CreateDIBitmap(HDC, CONST BITMAPINFOHEADER *, DWORD, CONST VOID *, CONST BITMAPINFO *, UINT);
int   WINAPI GetDIBits(HDC, HBITMAP, UINT, UINT, LPVOID, LPBITMAPINFO, UINT);
int   WINAPI SetDIBits(HDC, HBITMAP, UINT, UINT, CONST VOID *, CONST BITMAPINFO *, UINT);
UINT  WINAPI GetPaletteEntries(HPALETTE, UINT, UINT, LPPALETTEENTRY);
BOOL  WINAPI AnimatePalette(HPALETTE, UINT, UINT, CONST PALETTEENTRY *);
HBITMAP WINAPI CreateDIBSection(HDC, CONST BITMAPINFO *, UINT, VOID **, HANDLE, DWORD);
void CopyMemory(void*,const void*,INT); // rmm64bitux
BOOL GdiFlush();
BOOL IsBadWritePtr(LPVOID lp,UINT ucb);
DWORD SizeofResource(HMODULE hModule,HRSRC hResInfo);
SHORT GetAsyncKeyState(int);
DWORD OemKeyScan(WORD);
UINT MapVirtualKey(UINT,UINT);
SHORT VkKeyScan(CHAR);
BOOL MessageBeep(UINT);
UINT GetDoubleClickTime();
LPVOID XIgrabPointer(HWND);  // AE5098
void XIungrabPointer(LPVOID); // AE5098
HWND SetCapture(HWND);
BOOL ReleaseCapture();
BOOL ShowScrollBar(HWND hWnd,int wBar,BOOL bShow);
BOOL  WINAPI GetWindowOrgEx(HDC, LPPOINT);
BOOL ValidateRect(HWND hWnd,CONST RECT *lpRect);
int GetUpdateRgn(HWND hWnd,HRGN hRgn,BOOL bErase);
BOOL InvalidateRgn(HWND hWnd,HRGN hRgn,BOOL bErase);
int ScrollWindowEx(HWND hWnd,int dx,int dy,CONST RECT *prcScroll,CONST RECT *prcClip ,HRGN hrgnUpdate,LPRECT prcUpdate,UINT flags);

BOOL CreateCaret(HWND hWnd,HBITMAP hBitmap ,int nWidth,int nHeight);
BOOL DestroyCaret();
BOOL ShowCaret(HWND);
BOOL HideCaret(HWND);
BOOL GetCaretPos(LPPOINT lpPoint);
BOOL SetCaretPos(int x,int y);
HWND GetCaretWindow();
BOOL GetCaretRect(LPRECT pCaretRect);

VOID DragAcceptFiles(HWND,BOOL);
BOOL DragQueryPoint(HDROP,LPPOINT);
UINT DragQueryFile(HDROP,UINT,LPSTR,UINT);
VOID DragFinish(HDROP);
HWND GetCapture();
int SetScrollInfo(HWND, int, LPSCROLLINFO, BOOL);
void FillMemory(void* pDest, DWORD pLen, BYTE Fill); // MHCOMM
void ZeroMemory(void*,INT); // rmm64bitux
BOOL    WINAPI GetScrollInfo(HWND, int, LPSCROLLINFO);
typedef BOOL (CALLBACK* WNDENUMPROC)(HWND, LPARAM);
BOOL EnumChildWindows(HWND hWndParent,WNDENUMPROC lpEnumFunc,LPARAM lParam);
LONG  WINAPI GetBitmapBits(HBITMAP, LONG, LPVOID);
HICON CreateIcon(HINSTANCE hInstance,int nWidth,int nHeight,BYTE cPlanes, BYTE cBitsPixel,CONST BYTE *lpbANDbits,CONST BYTE *lpbXORbits);
int GetDlgCtrlID(HWND);
DWORD GetCurrentDirectory(DWORD nBufferLength,LPSTR lpBuffer);
BOOL SetEnvironmentVariable(LPCSTR lpName,LPCSTR lpValue);
HWND GetLastActivePopup(HWND);
ATOM GlobalAddAtom(LPCSTR lpString);
char* itoa(int, char *, int);
LRESULT DefDlgProc(HWND hDlg,UINT Msg,WPARAM wParam,LPARAM lParam);
HWND GetDlgItem(HWND hDlg,int nIDDlgItem);
BOOL SetDlgItemText(HWND hDlg,int nIDDlgItem,LPCSTR lpString);
BOOL GetTextExtentPoint(HDC,LPCSTR,int,LPSIZE);
LRESULT CallNextHookEx(HHOOK hhk,int nCode,WPARAM wParam,LPARAM lParam);
VOID keybd_event(BYTE bVk,BYTE bScan,DWORD dwFlags,DWORD dwExtraInfo);
HHOOK SetWindowsHookEx(int idHook,HOOKPROC lpfn,HINSTANCE hmod,DWORD dwThreadId);
OMTHREADID GetCurrentThreadId(); // rmm9567
BOOL UnhookWindowsHookEx(HHOOK);
int DialogBoxIndirectParam(HINSTANCE hInstance,LPCDLGTEMPLATE hDialogTemplate,HWND hWndParent,DLGPROC lpDialogFunc,LPARAM dwInitParam);
int DrawText(HDC hDC,LPCSTR lpString,int nCount,LPRECT lpRect,UINT uFormat);
BOOL  WINAPI Polyline(HDC, CONST POINT *, int);
// rmmcups: Note that text for all printer APIs in winprt.c must be UTF-8
BOOL  PrintDlg(LPPRINTDLG);
BOOL	JobSetupDlg(LPJOBSETUPDLG);	// rmmcups
void	UpdatePPDDevMode(char *pPrinterName, char *pPrinterInstance, LPDEVMODE pDevMode); // rmmcups
DWORD CommDlgExtendedError(VOID);
HDC   WINAPI CreateEnhMetaFile(HDC, LPCSTR, CONST RECT *, LPCSTR);
HENHMETAFILE WINAPI CloseEnhMetaFile(HDC);
int WINAPI StartDoc(HDC, CONST DOCINFO *);
int WINAPI EndDoc(HDC);
int  WINAPI Escape(HDC, int, int, LPCSTR, LPVOID);
HDC  WINAPI ResetDC(HDC, CONST DEVMODE *);
int WINAPI StartPage(HDC);
int WINAPI EndPage(HDC);
BOOL  WINAPI SetWindowExtEx(HDC, int, int, LPSIZE);
BOOL OpenPrinter(LPSTR pPrinterName,LPHANDLE phPrinter,LPPRINTER_DEFAULTS pDefault);
BOOL GetPrinter(HANDLE  hPrinter,DWORD   Level,LPBYTE  pPrinter,DWORD   cbBuf,LPDWORD pcbNeeded);
LONG AdvancedDocumentProperties(HWND hWnd,HANDLE hPrinter,LPSTR pDeviceName,PDEVMODE pDevModeOutput,PDEVMODE pDevModeInput);
BOOL ClosePrinter(HANDLE hPrinter);
// Start rmmcups
int  WINAPI DeviceCapabilities(LPCSTR pPrinter, LPCSTR pPort, WORD pCapability, LPSTR pOutput, CONST DEVMODE *pDevmode);
#define PAPER_NAME_BUFLEN 64
#define BIN_NAME_BUFLEN		24
// End rmmcups
LONG DocumentProperties(HWND hWnd,HANDLE hPrinter,LPSTR pDeviceName,PDEVMODE pDevModeOutput,PDEVMODE pDevModeInput,DWORD fMode);
// Start rmmcups
HDC WINAPI CreateIC(LPCSTR pDriver, LPCSTR pDevice, LPCSTR pPort, CONST DEVMODE *pDevmode);
HDC WINAPI CreateDC(LPCSTR pDriver, LPCSTR pDevice, LPCSTR pPort, CONST DEVMODE *pDevmode);
HDC WINAPI CreateDC25400();
LPTSTR ListPrinters(LPTSTR pOnlyPrinter);	
void FreePrinters(LPTSTR pList);
#ifndef BUILD_WINPRT
	typedef void * PRIPPD;
	int OpenPrinterPPD(LPCSTR pPrinter, PRIPPD **pPPD);
	HGLOBAL GetCopyOfDevmodeFromPPD(PRIPPD *pPPD);
	void GetPaperFromIndex(PRIPPD *pPPD, int pPaperIndex, LPDEVMODE pDevMode);
	void GetBinFromIndex(PRIPPD *pPPD, int pBinIndex, LPDEVMODE pDevMode);
#endif
void CopyDevModeSettings(HGLOBAL pSourceDevmode, HGLOBAL pDestDevmode);
void RestoreDefaultDevmode(LPDEVMODE pDevMode);
BOOL GetDevModeAndPrinterNameForPrintDlg(LPPRINTDLG pPrintDlg, HGLOBAL *pPrinterNameHan, HGLOBAL *pDevModeHan, char **pPrinterList);
HGLOBAL MakePrinterNameHan(char *pPrinterName);
HGLOBAL MakeDevModeHan(LPDEVMODE pDevMode);
int PrinterProperties(HGLOBAL pDevMode);
BOOL GetDeviceMarginInfo(char *pPrinterName, short pPaperSize, int *pLeft, int *pTop, int *pRight, int *pBottom);
void GetPaperName(LPDEVMODE pDevMode, char *name);
void GetBinName(LPDEVMODE pDevMode, char *name);
DWORD GetDefaultPrinterName(LPTSTR PrinterName, DWORD BufferSize);

// Structure used to keep the printer options for a printer.
#pragma pack(1)
// The actual DEVMODE has further data stored after it, at address (char *) (DEVMODE + 1)
// This is the driver extra data, and has the form:
typedef struct tagPRIoption
{
	int								mOptionLength;						// Total length of option including all its values
	short							mOptionType;							// PPD UI type (Boolean, pick many, pick one)
	short							mOptionNameLength;				// Length of option name (includes null terminator)
	short							mOptionUINameLength;			// Length of UI name of option (includes null terminator)
	short							mOptionValueMaxLength;		// Max length of a value of this option (includes 1 for null terminator)
	short							mOptionUIValueMaxLength;	// Max length of user interface string for a value of this option (includes 1 for null terminator)
	short							mOptionValueCount;				// Number of possible values for this option
	short							mReserved1;								// Must be zero
	short							mReserved2;								// Must be zero
	// The rest of the structure starts here; it has the form:
	// char						mOptionName[mOptionNameLength];
	// char						mOptionUIName[mOptionUINameLength];
	// PRIoptionValue	mOptionValue[mOptionValueCount];
	//		where each PRIoptionValue has the form
	//			char			mSelected;													// Non-zero if this value is selected (some values allow multiple selection)
	//			char			mValue[mOptionValueMaxLength];			// The value of the option
	//			char			mUIValue[mOptionUIValueMaxLength];	// The UI version of the value
} PRIoption;
#pragma pack()

// Note - these APIs use UTF-8, even in non-Unicode Studio
PRIoption *NextDevModeOption(LPDEVMODE pDevmode, PRIoption *pCurrentOption);
PRIoption *FindDevModeOption(LPDEVMODE pDevmode, char *pOption);
char *GetDevModeOptionName(PRIoption *pOpt);
char *GetDevModeOptionUIName(PRIoption *pOpt);
char *GetFirstDevModeOptionValue(PRIoption *pOpt);
char *GetNextDevModeOptionValue(PRIoption *pOpt, char *pValue);
char *GetDevModeOptionValueName(PRIoption *pOpt, char *pOptionValue);
char *GetDevModeOptionValueUIName(PRIoption *pOpt, char *pOptionValue);
BOOL IsDevModeOptionValueSelected(char *pOptionValue);
char *GetDevModeOptionValueSelectedPtr(char *pOptionValue);
BOOL SetDevModeOptionValueSelected(char *pOptionValue, BOOL pSelected);
void SetDevModeOptionValue(PRIoption *pOpt, char *pValue);
void DeselectAllOptionValues(PRIoption *pOpt);
// End rmmcups

// rmm9322: Always use SetLastError function to set the error
void SetLastError(DWORD);
void SetLastErrorString(LPCSTR);
void GetLastErrorString(LPSTR,int pLen);
void OutputDebugString(LPCTSTR);
void OutputKernelInfo();

// MHUX001 begins.
#define     _strcmpi(lp,ld)         \
                (lstrcmpi(lp,ld))
#define     _strupr(lp)         \
                (AnsiUpper(lp))
// MHUX001 ends.

// X Event functions
#define XEV_MSG_BUTTONDOWN   1
BOOL XEV_IsWindowQueued(HWND,INT);


// Control defines
#define EM_GETLINE   0x00C4
#define CB_ERR   (-1)
#define CB_GETCURSEL  0x0147
BOOL WINAPI CheckDlgButton(  HWND hDlg,int nIDButton,UINT uCheck);
LONG WINAPI SendDlgItemMessage(HWND hDlg,int nIDDlgItem,UINT Msg,WPARAM wParam,LPARAM lParam);

// OSresFunc types
typedef void* (WINAPI *OSRESCALL)(int,void*,void*,int);

#define RES_FUNC_FIND			0		// Find Resource (returns pointer to array element)
#define RES_FUNC_LOAD			1 	// Load Resource (returns structure to array element)
#define RES_FUNC_FREE			2 	// Free Resource (frees structure created by Load Resource)
#define RES_FUNC_LOCK			3 	// Lock Resource (allocs resource data and returns new pointer)
#define RES_FUNC_UNLOCK		4		// Unlock resource (frees data allocated by lock resource)
#define RES_FUNC_SIZE			5 	// Size of resource
#define RES_LOAD_STRING		6		// Load string
#define RES_VERSION        7
#define RES_GET_LAST_ID                8
#define RES_LIBRARY_LOAD                  9
#define RES_LIBRARY_UNLOAD             10


// Library functions
#define XIERROR_OK              0
#define XIERROR_BADCOLORDEPTH   1
#define XIERROR_XCONNECTFAIL    2
#define XIERROR_INITXFT					3	// rmmunilnx

int InitLib(char* pOmnisPath,FARPROC pResFunc,void *pDisplay); // Returns XIERROR_xxx
void SetNonUnicodeDrawing();											// rmmunilnx
void SetDisableAntiAlias(BOOL pDisableAntiAlias);	// rmmunilnx
void FreeLib();
void FlushEvents(BOOL pPostFlush);
void ConvFileName(LPSTR pFile);

typedef struct tagKERNELINFO
{
  DWORD mOSMAJOR;
  DWORD mOSMINOR;
  CHAR  mOSVERSION[32];
	DWORD mVERMAJOR;				 // XI_MAJOR
	DWORD mVERMINOR;				 // XI_MINOR
   DWORD mPID;
	DWORD mHMODULE;
	DWORD mHBITMAP;
	DWORD mHFONT;
	DWORD mHRGN;
	DWORD mHDC;
	DWORD mHMENU;
	DWORD mHMENUITEM;
	DWORD mHWND;
	DWORD mHBRUSH;
	DWORD mHPEN;
	DWORD mATOM;
	DWORD mFINDFILE;
	DWORD mTIMERS;
  DWORD mHFILE;
  DWORD mHICON;
	DWORD mSPARE[12];
} KERNELINFO;
void GetKernelInfo(KERNELINFO* pKernelInfo);

// Threads and semaphores
typedef void *LPSECURITY_ATTRIBUTES;
HANDLE CreateSemaphore(LPSECURITY_ATTRIBUTES lpSemaphoreAttributes, LONG lInitialCount,
											 LONG lMaximumCount, LPCSTR lpName);

typedef DWORD (*PTHREAD_START_ROUTINE)(LPVOID lpThreadParameter);
typedef PTHREAD_START_ROUTINE LPTHREAD_START_ROUTINE;

#define OM_THREAD_WILL_JOIN	0x100	// rmmheadless: Pass this in dwCreationFlags if the thread will be joined
HANDLE CreateThread(LPSECURITY_ATTRIBUTES lpThreadAttributes, DWORD dwStackSize, LPTHREAD_START_ROUTINE lpStartAddress,
									  LPVOID lpParameter, DWORD dwCreationFlags, OMTHREADID *lpThreadId); // rmmheadless: OMTHREADID

BOOL ReleaseSemaphore(HANDLE hSemaphore, LONG lReleaseCount, LONG *lpPreviousCount);

#define INFINITE            0xFFFFFFFF  // Infinite timeout
DWORD WaitForSingleObject(HANDLE hHandle, DWORD dwMilliseconds);

#define WAIT_FAILED (DWORD) 0xFFFFFFFF
#define WAIT_OBJECT_0 0

// Start rmm3524
// rmm9564: Removed redundant ResumeThread and SuspendThread (these were only partly implemented anyway)
BOOL SwitchToThread(); 
// End rmm3524

// Start rmm3766: thread local storage APIs used by omnis
DWORD TlsAlloc();
BOOL TlsSetValue(DWORD pIndex, LPVOID pValue);
LPVOID TlsGetValue(DWORD pIndex);
// End rmm3766

BOOL GetComputerName(LPSTR pName,LPDWORD pSize);   // Added 1.3
BOOL GetUserName(LPSTR pName,LPDWORD pSize);       // Added 1.3

// ae6169
void SetWindowOverride(DWORD pStyle,DWORD pExStyle,DWORD* pOldStyle,DWORD* pOldExStyle);
void AdjustWindowOverride(HWND pFrameWnd,HWND pHwnd);
void PaintWindowOverride(HWND pHwnd);

#define CHARSET_NONE     0    // Used to obtain current charset
#define CHARSET_ASCII    1
#define CHARSET_UTF8     2

char *ConvertUtf8ToISO8859(char *pString);											// rmmcups: caller must free return value
int ConvertUtf8ToISO8859WithDest(char *pString, char *pDest);		// rmmcups
char *ConvertISO8859ToUtf8(char *pString);											// rmmcups: caller must free return value
int ConvertISO8859ToUtf8WithDest(char *pString, char *pDest);		// rmmcups
int ConvertUtf8ToWideCharWithDest(char *pString, unsigned int *pDest);						// rmmunilnx3
int ConvertWideCharToUtf8WithDest(unsigned int *pString, char *pDest);						// rmmunilnx3
int ConvertWideCharToUtf16WithDest(unsigned int *pString, unsigned short *pDest);	// rmmunilnx3

#define	XI_UTF8_MAX_BYTES_PER_CHAR	3														// rmmcups: Maximum number of bytes per ISO8859-1 character when encoded in UTF-8

// AE Event log support
#define EVENTLOG_SUCCESS                0x0000
#define EVENTLOG_ERROR_TYPE             0x0001
#define EVENTLOG_WARNING_TYPE           0x0002
HANDLE RegisterEventSource(LPCSTR,LPCSTR);
BOOL ReportEvent(HANDLE,WORD,WORD,DWORD,DWORD,WORD,DWORD,LPCSTR*,LPVOID);
BOOL DeregisterEventSource(HANDLE);

// AECLIP 
#define EXTCLIPMSG_CLEAR   					0x0001	// Message to clear (or empty) clipboard
#define EXTCLIPMSG_ISFORMATAVAIL		0x0002	// Request if format available (pData1=format type),pResult=T/F after call 
#define EXTCLIPMSG_GETDATA   				0x0003	// pData1=Format type,pData2=HANDLE*
#define EXTCLIPMSG_SETDATA   				0x0004	// pData1=Format type,pData2=HANDLE
#define EXTCLIPMSG_INIT   					0x0005	
#define EXTCLIPMSG_TERM   					0x0006	
#define EXTCLIPMSG_RUNGNOMEEVENTS		0x0007	// rmm6879
// pData3 and pData4 are currently unused (remain for expansion)
typedef BOOL (CALLBACK* CLIPBRDHANDLERPROC)(int pMsg,DWORD* pResult,LPARAM pData1,LPARAM pData2,LPARAM pData3,LPARAM pData4); // Always return TRUE if handled

UINT GetKDEMajorVersion();	// rmm6807: returns 0 if not running under KDE

// Start rmm6814
// Called by the plugin to select the main HWND for processing the current events
BOOL XWindowSelectMainHwnd(HWND pMainHwnd, HWND *pPrevMainHwnd);
BOOL XWindowSelectMainHwndUsingWindow(DWORD pWindow, HWND *pPrevMainHwnd);	// pWindow is an X11 Window
// Called by the plugin after event processing to deselect the main HWND
// This allows us to find anywhere the main HWND needs to be selected, but has not been, because
// a crash will occur if that is the case.
void XWindowDeselectMainHwnd();
// End rmm6814

#ifdef __cplusplus
}
#endif

#pragma pack()

#endif
